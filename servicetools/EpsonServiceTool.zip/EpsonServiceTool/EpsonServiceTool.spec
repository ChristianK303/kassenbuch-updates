# -*- mode: python ; coding: utf-8 -*-
#
# Epson Service Tool (Drucker Tankwart) als einzelne .exe bauen.
#
# Bauen (im Ordner EpsonServiceTool, mit installierter requirements.txt,
# pyinstaller und pillow):
#     python -m PyInstaller --noconfirm EpsonServiceTool.spec
# Ergebnis: dist\EpsonServiceTool.exe

import glob
import os
import sysconfig
from PIL import Image
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

ICON_FILE = "build_icon.ico"
SPLASH_IMAGE = "build_splash.png"

Image.open(os.path.join("assets", "icon_256.png")).save(
    ICON_FILE, sizes=[(16, 16), (32, 32), (48, 48), (256, 256)]
)
logo = Image.open(os.path.join("assets", "header_logo.png")).convert("RGBA")
splash = Image.new("RGB", (420, 160), "white")
splash.paste(logo, ((420 - logo.width) // 2, 28), logo)
splash.paste(Image.new("RGB", (420, 6), "#951B54"), (0, 154))
splash.save(SPLASH_IMAGE)

# mypyc-Hilfsmodule (Name aendert sich je Paketversion) automatisch finden
mypyc_modules = sorted({
    os.path.basename(p).split(".")[0]
    for folder in {sysconfig.get_paths()["purelib"],
                   sysconfig.get_paths()["platlib"]}
    for p in glob.glob(os.path.join(folder, "*__mypyc*.pyd"))
})

hidden = (
    ["epson_usb_bridge", "zusatz_drucker", "drucker_db_generiert", "find_printers",
     "win32print", "win32api", "pyi_splash"]
    + mypyc_modules
    # pysnmp laedt MIB-Module und Protokollteile zur Laufzeit
    + collect_submodules("pysnmp")
    + collect_submodules("pysnmp_sync_adapter")
    + collect_submodules("pyasn1")
    + [m for m in collect_submodules("epson_usb")
       if not m.startswith("epson_usb.tests")]
    + collect_submodules("epson_escp2")
    + collect_submodules("pyprintlpr")
)
datas = [("assets", "assets")] + collect_data_files("pysnmp") \
    + collect_data_files("epson_escp2")

# Startskript: Startbild schliessen, sobald das Programm geladen ist
with open("est_gui.py", "w") as fh:
    fh.write(
        "import pyi_splash\n"
        "import logging\n"
        "import epson_tool\n"
        "pyi_splash.close()\n"
        "logging.basicConfig(level=logging.WARNING)\n"
        "epson_tool.run_gui()\n"
    )

a = Analysis(
    ["est_gui.py"],
    pathex=["."],
    binaries=[],
    datas=datas,
    hiddenimports=hidden,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)
pyz = PYZ(a.pure)
splash = Splash(
    SPLASH_IMAGE,
    binaries=a.binaries,
    datas=a.datas,
    text_pos=None,
    minify_script=True,
    always_on_top=True,
)
exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    splash,
    splash.binaries,
    [],
    name="EpsonServiceTool",
    icon=ICON_FILE,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

for f in (SPLASH_IMAGE, ICON_FILE, "est_gui.py"):
    try:
        os.remove(f)
    except OSError:
        pass
