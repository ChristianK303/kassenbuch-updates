@echo off
rem Installiert Python 3.13.17 fuer den aktuellen Benutzer (ohne Adminrechte).
cd /d "%~dp0"
set INST=python\python-3.13.17-amd64.exe
if not exist "%INST%" (
  echo Installer fehlt: %INST%
  pause
  exit /b 1
)
echo Pruefe die Installationsdatei ...
for /f "tokens=*" %%h in ('certutil -hashfile "%INST%" SHA256 ^| findstr /v ":"') do (
  set HASH=%%h
  goto :check
)
:check
set HASH=%HASH: =%
if /i not "%HASH%"=="5da012101ba2e17113a9a1cd901e9ce1441086f2b7ecb5de06ec94163899a190" (
  echo Pruefsumme stimmt nicht - Datei ist beschaedigt oder veraendert. Abbruch.
  pause
  exit /b 1
)
echo Pruefsumme OK. Installation laeuft, bitte warten ...
"%INST%" /passive InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_tcltk=1 Include_pip=1 Include_test=0
if errorlevel 1 (
  echo Installation fehlgeschlagen oder abgebrochen.
  pause
  exit /b 1
)
echo.
echo Python ist installiert. Jetzt start.bat doppelklicken.
pause
