"""
Epson Service Tool - eigenes Windows-Programm fuer Epson-Tintenstrahldrucker.

Liest Status, Tintenstaende und Zaehler ueber Netzwerk (SNMP) oder USB aus und
bietet Wartungsfunktionen (Duesentest, Reinigung, Resttintenzaehler).

Protokoll und Modelldaten stammen aus dem Open-Source-Projekt
"epson_print_conf" von Ircama (EUPL-1.2), das als Bibliothek neben dieser
Datei liegt: https://github.com/Ircama/epson_print_conf
USB laeuft ueber die Bibliothek "epson-usb"; unter Windows nutzt sie den
vorhandenen Epson-Treiber (USBPRINT), es wird kein Treiber ersetzt.
"""
import json
import logging
import queue
import sys
import threading
import time
import warnings
from pathlib import Path

warnings.filterwarnings("ignore", category=SyntaxWarning)

import epson_print_conf as epc  # noqa: E402
from epson_print_conf import EpsonPrinter, get_printer_models  # noqa: E402
from find_printers import PrinterScanner  # noqa: E402
import zusatz_drucker  # noqa: E402

zusatz_drucker.register(EpsonPrinter)  # z. B. ET-2850 / L4260-Familie

try:
    from epson_usb_bridge import usb_printer
    UsbEpsonPrinter = usb_printer(EpsonPrinter)
except Exception as _usb_err:  # Bibliothek fehlt
    UsbEpsonPrinter = None
    USB_ERROR = str(_usb_err)
else:
    USB_ERROR = None

APP_NAME = "Epson Service Tool"
BRAND_NAME = "Drucker Tankwart"
ASSET_DIR = Path(__file__).resolve().parent / "assets"

# Farben aus dem Drucker-Tankwart-Logo
COLORS = {
    "brand": "#951B54",        # Logofarbe (Beere)
    "brand_dark": "#6E1440",   # gedrueckt / Statusleiste
    "brand_hover": "#A8336B",
    "brand_light": "#F6E8EF",  # Flaechen, Balkenhintergrund
    "bg": "#FBF8F9",           # Fensterhintergrund
    "surface": "#FFFFFF",
    "border": "#E4D3DB",
    "text": "#2E1A24",
    "muted": "#7A6570",
}
FONT = "Segoe UI"
WASTE_KEYS = ("main_waste", "borderless_waste", "first_waste",
              "second_waste", "third_waste")
WASTE_LABELS = {
    "main_waste": "Hauptzaehler",
    "borderless_waste": "Randlosdruck",
    "first_waste": "Zaehler 1",
    "second_waste": "Zaehler 2",
    "third_waste": "Zaehler 3",
}


# --------------------------------------------------------------------------
# USB und Windows-Druckerwarteschlange
# --------------------------------------------------------------------------
def list_usb_printers():
    """Angeschlossene Epson-USB-Drucker als [(Anzeigename, DeviceInfo)].

    Derselbe Drucker taucht pro Backend und (unter Windows) pro USB-Interface
    auf; es wird je Backend-Sicht nur ein Eintrag behalten.
    """
    if UsbEpsonPrinter is None:
        raise RuntimeError("USB-Bibliothek fehlt: " + str(USB_ERROR))
    from epson_usb.backends import find_devices
    seen, result = set(), []
    for info in find_devices():
        key = epc._usb_device_key(info)
        if key in seen:
            continue
        seen.add(key)
        label = "USB {} [{}]".format(
            info.description or "Epson", epc._usb_identity(info))
        result.append((label, info))
    # Windows-eigener Weg zuerst (kein Treibertausch noetig)
    result.sort(key=lambda item: item[1].backend != "usbprint")
    return result


def windows_queues():
    """Namen der installierten Windows-Drucker (fuer Druckauftraege)."""
    if sys.platform != "win32":
        return []
    try:
        import win32print
    except ImportError:
        return []
    flags = win32print.PRINTER_ENUM_LOCAL | win32print.PRINTER_ENUM_CONNECTIONS
    return [p[2] for p in win32print.EnumPrinters(flags)]


def guess_queue(queues, model):
    """Passende Warteschlange: zuerst nach Modell, sonst erste Epson."""
    lowered = [(q, q.lower()) for q in queues]
    if model:
        for q, low in lowered:
            if model.lower() in low:
                return q
    return next((q for q, low in lowered if "epson" in low), "")


def send_raw_to_queue(queue_name, data, title):
    """Schickt rohe ESC/P2-Daten an eine Windows-Warteschlange."""
    import win32print
    handle = win32print.OpenPrinter(queue_name)
    try:
        win32print.StartDocPrinter(handle, 1, (title, None, "RAW"))
        try:
            win32print.StartPagePrinter(handle)
            win32print.WritePrinter(handle, data)
            win32print.EndPagePrinter(handle)
        finally:
            win32print.EndDocPrinter(handle)
    finally:
        win32print.ClosePrinter(handle)
    return True


# --------------------------------------------------------------------------
# Fachlogik ohne Oberflaeche (damit sie getestet werden kann)
# --------------------------------------------------------------------------
class PrinterSession:
    """Eine Verbindung zu einem Drucker, per Netzwerk oder USB.

    hostname gesetzt  -> Netzwerk (SNMP, Drucken per LPR)
    usb_device gesetzt -> USB (EPSON-CTRL ueber IEEE 1284.4, Drucken ueber
                          die Windows-Warteschlange `print_queue`)
    """

    def __init__(self, hostname=None, model=None, printer_cls=None,
                 usb_device=None, usb_backend=None, usb_options=None,
                 print_queue=None, raw_sender=send_raw_to_queue):
        if not hostname and usb_device is None:
            raise ValueError("Weder IP noch USB-Geraet angegeben.")
        self.hostname = hostname
        self.usb_device = usb_device
        self.usb_backend = usb_backend
        self.usb_options = usb_options
        self.print_queue = print_queue
        self._send_raw = raw_sender
        if printer_cls is None:
            printer_cls = EpsonPrinter if hostname else UsbEpsonPrinter
            if printer_cls is None:
                raise RuntimeError("USB-Bibliothek fehlt: " + str(USB_ERROR))
        self._cls = printer_cls
        self.model = model
        self.printer = self._build(model)

    @property
    def is_usb(self):
        return not self.hostname

    @property
    def target(self):
        return self.hostname or "USB"

    def _build(self, model, usb_printer=None):
        if not self.is_usb:
            return self._cls(hostname=self.hostname, model=model)
        kwargs = {"model": model, "device": self.usb_device}
        if usb_printer is not None:
            kwargs["usb_printer"] = usb_printer
        if self.usb_backend:
            kwargs["backend"] = self.usb_backend
        if self.usb_options:
            kwargs["usb_options"] = self.usb_options
        return self._cls(**kwargs)

    def close(self):
        close = getattr(self.printer, "close", None)
        if close:
            close()

    @staticmethod
    def known_models(printer_cls=EpsonPrinter):
        return sorted(printer_cls().valid_printers)

    def reported_model(self):
        """Modellname, wie ihn der Drucker selbst meldet."""
        if self.is_usb:
            ident = self.printer.get_device_identification() or {}
            values = ident.get("Model") or ident.get("Description") or [""]
            return (values[0] if isinstance(values, list) else values).strip()
        info = self.printer.get_snmp_info("Model") or {}
        return (info.get("Model") or "").strip()

    def detect_model(self):
        """Fragt den Modellnamen ab und sucht die passende Konfiguration."""
        name = self.reported_model()
        match = None
        if name:
            valid = self.printer.valid_printers
            candidates = [name] + get_printer_models(name)
            match = next((c for c in candidates if c in valid), None)
        if match:
            self.set_model(match)
        return name, match

    def set_model(self, model):
        if model == self.model:
            return
        usb = getattr(self.printer, "usb", None) if self.is_usb else None
        if usb is None:
            self.close()
        self.model = model
        # USB: die offene D4-Verbindung weiterverwenden. Schliessen und sofort
        # neu verbinden scheitert bei manchen Druckern ("D4 Init failed").
        self.printer = self._build(model, usb_printer=usb)

    def read_all(self):
        """Liest alles Lesbare; einzelne Fehler brechen den Rest nicht ab."""
        p = self.printer
        out = {}
        errors = []

        def attempt(key, func):
            try:
                value = func()
                if value not in (None, "", {}, []):
                    out[key] = value
            except TimeoutError as exc:  # Drucker gar nicht erreichbar
                errors.append(str(exc))
            except Exception as exc:  # Drucker antwortet je nach Modell anders
                logging.warning("%s: %s", key, exc)

        if self.is_usb:
            attempt("Geraet", p.get_device_identification)
        else:
            attempt("Allgemein", p.get_snmp_info)
        attempt("Status", p.get_printer_status)
        if p.parm:
            attempt("Seriennummer", p.get_serial_number)
            attempt("Firmware", p.get_firmware_version)
            attempt("Zaehler", p.get_stats)
            attempt("Resttinte", p.get_waste_ink_levels)
        if not out and errors:
            raise ConnectionError(errors[0])
        return out

    def waste_addresses(self):
        parm = self.printer.parm or {}
        addrs = set(parm.get("raw_waste_reset", {}).keys())
        for key in WASTE_KEYS:
            addrs.update(parm.get(key, {}).get("oids", []))
        addrs.update(parm.get("waste_reset_commit", {}).keys())
        return sorted(a for a in addrs if isinstance(a, int))

    def can_reset_waste(self):
        parm = self.printer.parm or {}
        return bool("write_key" in parm and (
            "raw_waste_reset" in parm or "main_waste" in parm))

    def backup_waste(self, folder):
        """Sichert die betroffenen EEPROM-Zellen vor dem Schreiben."""
        addrs = self.waste_addresses()
        values = self.printer.read_eeprom(addrs, label="backup")
        if not values or any(v is None for v in values):
            raise RuntimeError(
                "EEPROM konnte nicht gelesen werden - kein Schreibzugriff.")
        path = Path(folder) / "eeprom_backup_{}_{}.json".format(
            self.model, time.strftime("%Y%m%d_%H%M%S"))
        path.write_text(json.dumps({
            "model": self.model, "connection": self.target,
            "cells": {str(a): v for a, v in zip(addrs, values)},
        }, indent=2), encoding="utf-8")
        return path

    def reset_waste(self, backup_folder):
        if not self.can_reset_waste():
            raise RuntimeError(
                "Fuer dieses Modell sind keine Zaehlerdaten hinterlegt.")
        backup = self.backup_waste(backup_folder)
        report = []
        ok = self.printer.reset_waste_ink_levels(report=report)
        return bool(ok), backup, self.printer.get_waste_ink_levels()

    # Druckfunktionen: Netzwerk per LPR (Bibliothek), USB ueber Windows
    def _print_usb(self, data, title):
        if not self.print_queue:
            raise RuntimeError(
                "Fuer USB bitte die Windows-Druckerwarteschlange waehlen.")
        return bool(self._send_raw(self.print_queue, data, title))

    def nozzle_check(self):
        if self.is_usb:
            from epson_escp2.epson_encode import EpsonEscp2
            return self._print_usb(EpsonEscp2().check_nozzles(type=0),
                                   "Duesentest")
        return bool(self.printer.print_check_nozzles())

    def clean(self):
        if self.is_usb:
            from epson_escp2.epson_encode import EpsonEscp2
            return self._print_usb(EpsonEscp2().clean_nozzles(0),
                                   "Kopfreinigung")
        return bool(self.printer.print_clean_nozzles(0))


def flatten(data, indent=0):
    """Macht aus verschachtelten Ergebnissen lesbare Textzeilen."""
    pad = "  " * indent
    lines = []
    if isinstance(data, dict):
        for key, value in data.items():
            if isinstance(value, (dict, list, tuple)) and value:
                lines.append(f"{pad}{key}:")
                lines.extend(flatten(value, indent + 1))
            else:
                lines.append(f"{pad}{key}: {value}")
    elif isinstance(data, (list, tuple)):
        if isinstance(data, tuple) and not any(
                isinstance(i, (dict, list, tuple)) for i in data):
            return [pad + ", ".join(str(i) for i in data)]
        for item in data:
            if isinstance(item, (dict, list, tuple)):
                lines.extend(flatten(item, indent))
            else:
                lines.append(f"{pad}{item}")
    else:
        lines.append(f"{pad}{data}")
    return lines


def ink_levels(status):
    """Liefert [(Farbe, Prozent)] aus dem Statusblock, soweit vorhanden."""
    result = []
    for item in (status or {}).get("ink_level", []) or []:
        # Aufbau: (Slot, Farbcode, Slotname, Farbname, Fuellstand)
        if isinstance(item, (list, tuple)) and len(item) >= 5:
            try:
                result.append((str(item[3]), int(item[4])))
            except (TypeError, ValueError):
                continue
    return result


# --------------------------------------------------------------------------
# Oberflaeche
# --------------------------------------------------------------------------
def load_image(tk, name):
    """PNG aus dem assets-Ordner laden; None, falls es fehlt."""
    path = ASSET_DIR / name
    if not path.exists():
        return None
    try:
        return tk.PhotoImage(file=str(path))
    except tk.TclError:
        return None


def apply_style(root, ttk):
    """Farbschema und Schriften im Stil des Drucker-Tankwart-Logos."""
    c = COLORS
    root.configure(background=c["bg"])
    # Standardschriften setzen (kein "*Font" - das wuerde die Styles der
    # Labels ueberschreiben)
    from tkinter import font as tkfont
    for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont"):
        tkfont.nametofont(name).configure(family=FONT, size=10)
    # Aufklappliste der Comboboxen
    root.option_add("*TCombobox*Listbox.background", c["surface"])
    root.option_add("*TCombobox*Listbox.foreground", c["text"])
    root.option_add("*TCombobox*Listbox.selectBackground", c["brand"])
    root.option_add("*TCombobox*Listbox.selectForeground", "white")

    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure(".", background=c["bg"], foreground=c["text"],
                    font=(FONT, 10), bordercolor=c["border"],
                    focuscolor=c["brand"], lightcolor=c["bg"],
                    darkcolor=c["bg"], troughcolor=c["brand_light"])
    style.configure("TFrame", background=c["bg"])
    style.configure("Card.TFrame", background=c["surface"])
    style.configure("Header.TFrame", background=c["surface"])
    style.configure("TLabel", background=c["bg"], foreground=c["text"])
    style.configure("Muted.TLabel", foreground=c["muted"])
    style.configure("Section.TLabel", foreground=c["brand"],
                    font=(FONT, 11, "bold"))
    style.configure("Card.TLabel", background=c["surface"])
    style.configure("HeaderTitle.TLabel", background=c["surface"],
                    foreground=c["brand"], font=(FONT, 16, "bold"))
    style.configure("HeaderSub.TLabel", background=c["surface"],
                    foreground=c["muted"], font=(FONT, 9))
    style.configure("Status.TLabel", background=c["brand_dark"],
                    foreground="white", font=(FONT, 9))

    # Normale Buttons: weiss mit Beeren-Schrift
    style.configure("TButton", background=c["surface"],
                    foreground=c["brand"], bordercolor=c["brand"],
                    lightcolor=c["surface"], darkcolor=c["surface"],
                    font=(FONT, 10, "bold"), padding=(12, 6),
                    focusthickness=1)
    style.map("TButton",
              background=[("disabled", c["bg"]), ("pressed", c["brand_light"]),
                          ("active", c["brand_light"])],
              foreground=[("disabled", c["muted"])],
              bordercolor=[("disabled", c["border"])])
    # Hauptaktionen: Beere gefuellt
    style.configure("Accent.TButton", background=c["brand"],
                    foreground="white", bordercolor=c["brand"],
                    lightcolor=c["brand"], darkcolor=c["brand"])
    style.map("Accent.TButton",
              background=[("disabled", c["border"]),
                          ("pressed", c["brand_dark"]),
                          ("active", c["brand_hover"])],
              lightcolor=[("pressed", c["brand_dark"]),
                          ("active", c["brand_hover"])],
              darkcolor=[("pressed", c["brand_dark"]),
                         ("active", c["brand_hover"])],
              foreground=[("disabled", "white")])

    style.configure("TCombobox", fieldbackground=c["surface"],
                    background=c["surface"], foreground=c["text"],
                    arrowcolor=c["brand"], bordercolor=c["border"],
                    lightcolor=c["surface"], darkcolor=c["surface"],
                    padding=4)
    style.map("TCombobox",
              bordercolor=[("focus", c["brand"])],
              fieldbackground=[("readonly", c["surface"])],
              selectbackground=[("focus", c["brand"])],
              selectforeground=[("focus", "white")])

    style.configure("Horizontal.TProgressbar", background=c["brand"],
                    troughcolor=c["brand_light"], bordercolor=c["border"],
                    lightcolor=c["brand"], darkcolor=c["brand"],
                    thickness=12)
    style.configure("Vertical.TScrollbar", background=c["brand_light"],
                    troughcolor=c["bg"], bordercolor=c["bg"],
                    arrowcolor=c["brand"], lightcolor=c["brand_light"],
                    darkcolor=c["brand_light"])
    style.configure("TPanedwindow", background=c["bg"])
    style.configure("Sash", sashthickness=6, background=c["bg"])


def run_gui():
    import tkinter as tk
    from tkinter import messagebox, simpledialog, ttk

    root = tk.Tk()
    root.title(f"{APP_NAME} - {BRAND_NAME}")
    root.geometry("980x680")
    root.minsize(760, 520)
    apply_style(root, ttk)
    images = {}  # Referenzen halten, sonst raeumt Tk die Bilder weg
    icons = [img for img in (load_image(tk, f"icon_{s}.png")
                             for s in (256, 48, 32, 16)) if img]
    if icons:
        images["icons"] = icons
        root.iconphoto(True, *icons)
    results = queue.Queue()
    state = {"session": None}
    backup_dir = Path.home() / "Documents" / "EpsonServiceTool"

    # Kopfzeile mit Logo
    header = ttk.Frame(root, style="Header.TFrame", padding=(16, 10))
    header.pack(fill="x")
    logo = load_image(tk, "header_logo.png")
    if logo:
        images["logo"] = logo
        ttk.Label(header, image=logo, style="Card.TLabel").pack(side="left")
    else:
        ttk.Label(header, text=BRAND_NAME.upper(),
                  style="HeaderTitle.TLabel").pack(side="left")
    titles = ttk.Frame(header, style="Header.TFrame")
    titles.pack(side="right")
    ttk.Label(titles, text=APP_NAME, style="HeaderTitle.TLabel").pack(
        anchor="e")
    ttk.Label(titles, text="Status, Tinte und Wartung fuer Epson-Drucker",
              style="HeaderSub.TLabel").pack(anchor="e")
    tk.Frame(root, height=3, background=COLORS["brand"]).pack(fill="x")

    top = ttk.Frame(root, padding=(16, 12))
    top.pack(fill="x")
    found = {}  # Anzeigename -> {"usb": DeviceInfo} oder {"ip": "..."}
    ttk.Label(top, text="Drucker:").grid(row=0, column=0, sticky="w")
    host_var = tk.StringVar()
    host_box = ttk.Combobox(top, textvariable=host_var, width=34)
    host_box.grid(row=0, column=1, padx=6)
    ttk.Label(top, text="Windows-Drucker:").grid(
        row=1, column=0, sticky="w", pady=(8, 0))
    queue_var = tk.StringVar()
    queue_box = ttk.Combobox(top, textvariable=queue_var, width=34,
                             values=windows_queues())
    queue_box.grid(row=1, column=1, padx=6, pady=(8, 0))
    ttk.Label(top, text="fuer Duesentest/Reinigung per USB",
              style="Muted.TLabel").grid(row=1, column=2, columnspan=3,
                                         sticky="w", padx=6, pady=(8, 0))
    ttk.Label(top, text="Modell:").grid(row=0, column=3, padx=(16, 0))
    model_var = tk.StringVar()
    model_box = ttk.Combobox(top, textvariable=model_var, width=22,
                             values=PrinterSession.known_models())
    model_box.grid(row=0, column=4, padx=6)

    status_var = tk.StringVar(value="Bereit.")
    ttk.Label(root, textvariable=status_var, style="Status.TLabel",
              padding=(16, 6)).pack(fill="x", side="bottom")

    body = ttk.Panedwindow(root, orient="horizontal")
    body.pack(fill="both", expand=True, padx=16, pady=(0, 12))
    left = ttk.Frame(body, padding=(0, 0, 12, 0))
    right = ttk.Frame(body)
    body.add(left, weight=1)
    body.add(right, weight=3)

    ttk.Label(left, text="Tintenstaende", style="Section.TLabel").pack(
        anchor="w")
    ink_frame = ttk.Frame(left)
    ink_frame.pack(fill="x", pady=(4, 14))
    ttk.Label(left, text="Resttintenzaehler", style="Section.TLabel").pack(
        anchor="w")
    waste_frame = ttk.Frame(left)
    waste_frame.pack(fill="x", pady=(4, 14))
    ttk.Label(left, text="Wartung", style="Section.TLabel").pack(anchor="w")

    text_box = tk.Frame(right, background=COLORS["surface"],
                        highlightthickness=1,
                        highlightbackground=COLORS["border"])
    text_box.pack(fill="both", expand=True)
    text = tk.Text(text_box, wrap="none", font=("Consolas", 10),
                   background=COLORS["surface"], foreground=COLORS["text"],
                   selectbackground=COLORS["brand"],
                   selectforeground="white", insertbackground=COLORS["brand"],
                   relief="flat", borderwidth=0, padx=12, pady=10)
    scroll = ttk.Scrollbar(text_box, command=text.yview)
    text.configure(yscrollcommand=scroll.set, state="disabled")
    scroll.pack(side="right", fill="y")
    text.pack(fill="both", expand=True)

    def show(lines):
        text.configure(state="normal")
        text.delete("1.0", "end")
        text.insert("end", "\n".join(lines))
        text.configure(state="disabled")

    def bars(frame, items):
        for child in frame.winfo_children():
            child.destroy()
        if not items:
            ttk.Label(frame, text="keine Daten", style="Muted.TLabel").pack(
                anchor="w")
        for name, percent in items:
            row = ttk.Frame(frame)
            row.pack(fill="x", pady=2)
            ttk.Label(row, text=name, width=16).pack(side="left")
            ttk.Progressbar(row, maximum=100, length=110,
                            value=max(0, min(100, percent))).pack(side="left")
            ttk.Label(row, text=f" {percent:g} %").pack(side="left")

    def background(label, func, done):
        status_var.set(label + " ...")
        for b in buttons:
            b.state(["disabled"])

        def worker():
            try:
                results.put((done, func(), None))
            except Exception as exc:
                results.put((done, None, exc))
        threading.Thread(target=worker, daemon=True).start()

    def poll():
        try:
            while True:
                done, value, error = results.get_nowait()
                for b in buttons:
                    b.state(["!disabled"])
                if error:
                    status_var.set("Fehler.")
                    messagebox.showerror(APP_NAME, str(error))
                else:
                    done(value)
        except queue.Empty:
            pass
        root.after(150, poll)

    def session():
        label = host_var.get().strip()
        if not label:
            messagebox.showinfo(APP_NAME, "Bitte zuerst 'Drucker suchen' "
                                          "oder eine IP eintragen.")
            return None
        entry = found.get(label) or {"ip": label.split(" ")[0]}
        key = ("usb", entry["usb"].path) if "usb" in entry else (
            "ip", entry["ip"])
        model = model_var.get().strip() or None
        s = state["session"]
        if s and state.get("key") == key:
            if model and model != s.model:
                s.set_model(model)
        else:
            if s:
                s.close()
            try:
                if "usb" in entry:
                    info = entry["usb"]
                    s = PrinterSession(usb_device=info.path,
                                       usb_backend=info.backend, model=model)
                else:
                    s = PrinterSession(entry["ip"], model)
            except Exception as exc:
                messagebox.showerror(APP_NAME, str(exc))
                return None
            state["session"], state["key"] = s, key
        s.print_queue = queue_var.get().strip() or None
        return s

    def do_scan():
        def job():
            usb, net, notes = [], [], []
            try:
                usb = list_usb_printers()
            except Exception as exc:
                notes.append(f"USB: {exc}")
            try:
                net = PrinterScanner().get_all_printers()
            except Exception as exc:
                notes.append(f"Netzwerk: {exc}")
            return usb, net, notes

        def done(value):
            usb, net, notes = value
            found.clear()
            for label, info in usb:
                found[label] = {"usb": info}
            for p in net:
                label = "{} ({})".format(p["ip"], p.get("name") or "?")
                found[label] = {"ip": p["ip"]}
            host_box["values"] = list(found)
            if found:
                host_var.set(next(iter(found)))
            queues = windows_queues()
            queue_box["values"] = queues
            if not queue_var.get():
                queue_var.set(guess_queue(queues, model_var.get()))
            status_var.set(f"{len(usb)} USB, {len(net)} Netzwerk gefunden. "
                           + " ".join(notes))
        background("Suche USB und Netzwerk", job, done)

    def do_read():
        s = session()
        if not s:
            return

        def job():
            name = None
            if not s.model:
                name, match = s.detect_model()
            return name, s.read_all()

        def done(value):
            name, data = value
            if s.model:
                model_var.set(s.model)
                if s.is_usb and not queue_var.get():
                    queue_var.set(guess_queue(windows_queues(), s.model))
            show(flatten(data) or ["Keine Antwort vom Drucker."])
            bars(ink_frame, ink_levels(data.get("Status")))
            bars(waste_frame, [(WASTE_LABELS.get(k, k), v) for k, v in
                               (data.get("Resttinte") or {}).items()])
            if not data:
                status_var.set("Keine Antwort. Kabel bzw. IP/SNMP pruefen.")
            elif not s.model:
                status_var.set(f"Modell '{name}' nicht in der Datenbank - "
                               "nur Basisdaten. Modell manuell waehlen.")
            else:
                status_var.set(f"Gelesen: {s.model} @ {s.target}")
        background("Lese Drucker", job, done)

    def simple_action(label, method, question):
        s = session()
        if s and messagebox.askyesno(APP_NAME, question):
            background(label, getattr(s, method), lambda ok: status_var.set(
                label + (": gesendet." if ok else ": fehlgeschlagen.")))

    def do_reset():
        s = session()
        if not s:
            return
        if not s.can_reset_waste():
            messagebox.showwarning(
                APP_NAME, "Fuer das gewaehlte Modell sind keine "
                "Zaehleradressen hinterlegt. Bitte Modell pruefen.")
            return
        typed = simpledialog.askstring(
            APP_NAME,
            "Der Resttintenzaehler schuetzt vor dem Ueberlaufen der "
            "Tintenschwaemme.\n\nNur zuruecksetzen, wenn die Schwaemme "
            "getauscht oder ein externer Auffangbehaelter montiert wurde - "
            "sonst kann Tinte auslaufen.\n\nEs wird ins EEPROM geschrieben; "
            "ein falsches Modell kann den Drucker unbrauchbar machen. "
            f"Gewaehlt: {s.model}\n\nZur Bestaetigung RESET eintippen:")
        if typed != "RESET":
            status_var.set("Abgebrochen.")
            return
        backup_dir.mkdir(parents=True, exist_ok=True)

        def done(value):
            ok, backup, levels = value
            bars(waste_frame, [(WASTE_LABELS.get(k, k), v)
                               for k, v in (levels or {}).items()])
            status_var.set("Zaehler zurueckgesetzt." if ok
                           else "Zuruecksetzen fehlgeschlagen.")
            messagebox.showinfo(
                APP_NAME, ("Erfolgreich." if ok else "Fehlgeschlagen.") +
                f"\nSicherung: {backup}\nDrucker jetzt aus- und einschalten.")
        background("Setze Zaehler zurueck",
                   lambda: s.reset_waste(backup_dir), done)

    buttons = [
        ttk.Button(top, text="Drucker suchen", command=do_scan),
        ttk.Button(top, text="Auslesen", command=do_read,
                   style="Accent.TButton"),
    ]
    buttons[0].grid(row=0, column=2, padx=6)
    buttons[1].grid(row=0, column=5, padx=6)
    for label, cmd in (
        ("Duesentest drucken", lambda: simple_action(
            "Duesentest", "nozzle_check", "Duesentest jetzt drucken?")),
        ("Kopfreinigung", lambda: simple_action(
            "Kopfreinigung", "clean",
            "Kopfreinigung starten? Verbraucht Tinte.")),
        ("Resttintenzaehler zuruecksetzen", do_reset),
    ):
        b = ttk.Button(left, text=label, command=cmd)
        b.pack(fill="x", pady=3)
        buttons.append(b)

    bars(ink_frame, [])
    bars(waste_frame, [])
    show([APP_NAME, "",
          "1. 'Drucker suchen' (USB und Netzwerk) oder IP eintragen",
          "2. Auslesen",
          "3. Modell pruefen, dann ggf. Wartungsfunktion",
          "",
          "USB: Duesentest und Reinigung laufen ueber den gewaehlten",
          "Windows-Drucker. Auslesen und Zaehler gehen direkt ans Geraet."])
    if USB_ERROR:
        status_var.set("USB nicht verfuegbar: " + USB_ERROR)

    def on_close():
        if state["session"]:
            state["session"].close()
        root.destroy()
    root.protocol("WM_DELETE_WINDOW", on_close)
    poll()
    root.mainloop()


if __name__ == "__main__":
    logging.basicConfig(level=logging.WARNING)
    run_gui()
