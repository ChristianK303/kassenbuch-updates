r"""Give ``EpsonPrinter`` a USB transport by subclassing it, not by patching it.

``epson_print_conf`` reaches the printer through exactly one door::

    printer.fetch_oid_values(oid)      # SNMP GET of an OID

Every feature it has -- EEPROM read and write, the ``st``/``di``/``vi``/``rw``
service commands, waste ink levels, the temporary waste reset, the full status
decode -- is built on top of that one call, with the OID produced by
``EpsonPrinter.epctrl_snmp_oid``. The message carried inside the OID is
*already* the EPSON-CTRL frame that the USB link has to carry: SNMP is only the
envelope.

The subclass overrides that single method and parses the OID back into bytes:

.. code-block:: python

    from epson_usb_bridge import usb_printer
    from epson_print_conf import EpsonPrinter

    UsbEpsonPrinter = usb_printer(EpsonPrinter)          # subclass

    printer = UsbEpsonPrinter(model="XP-205")            # no hostname: USB
    print(printer.read_eeprom(0x30))                     # '3B'
    print(printer.get_waste_ink_levels())                # {'main_waste': 6.11, ...}

Two hooks, and no data
----------------------

This module deliberately carries **no printer model data**. The host already has
its own ``PRINTER_CONFIG`` and it is the authoritative source for the printer in
use, so the normal path needs nothing from here: the keys are inside the OIDs
the host builds. The two hooks exist for the cases where a caller knows
something the host does not:

``params=``
    A mapping ``{model name: host parm dict}``. It is handed to the host as
    ``conf_dict``, so a model the host has never heard of can still be used.
    Where those parameters come from is entirely the caller's business; entries
    the host already has with a usable ``read_key`` are never replaced, because
    disagreeing with the host about the printer in use is how you write to the
    wrong cells.

``usb_factory=``
    A callable that builds the underlying
    :class:`~epson_usb.printer.EpsonUsbPrinter`. A caller that keeps its own
    EEPROM keys uses it to have ``printer.usb`` be a keyed object, so that the
    extras built on top of it (reading a cell, writing a cell set) work on the
    *same* open device instead of a second one.

Choosing the USB interface
--------------------------

A printer exposes several USB interfaces and only one of them answers D4, but
which one is not something the descriptors say reliably: the L3250 measured for
issue #35 has a vendor-specific interface 0 that never answers and interface 1
that works. That choice is the library's since ``epson-usb`` 0.1.2: its
``EpsonUsbPrinter.open()`` walks the candidate interfaces of the device
(``Transport.next_candidate()``) when the handshake gets no answer, and an
explicit ``interface=N`` turns both the automatic choice and the fallback off.
The bridge simply forwards ``interface=`` when the caller supplies it (the
``--interface`` option of the command line, or ``usb_options={'interface': N}``),
so nothing about the interface has to be reimplemented here.

What cannot work over USB, and says so instead of pretending:

* plain MIB OIDs (``get_snmp_info``) -- there is no SNMP agent on a USB cable,
  so those queries answer "unavailable" and are logged;
* printing (``print_check_nozzles``, ``print_clean_nozzles``, ...) -- the host
  sends those through LPR to a network address (see the GUI: the buttons are
  disabled in USB mode with that reason);
* ``brute_force_read_key`` on a locked firmware: the EEPROM stays locked over
  USB only when the *firmware* locks it, in which case the ``rw`` service
  command (``temporary_reset_waste``) is the one that still works, because it
  needs only the serial number.
"""

from __future__ import annotations

import inspect
import logging
import re
import time
from collections import deque
from pathlib import Path
from typing import Callable, List, Mapping, Optional, Sequence, Type

from epson_usb.backends import open_transport
from epson_usb.backends.base import Transport
from epson_usb.d4 import D4_ENTER_SEQUENCE, EpsonCtrlSession
from epson_usb.errors import D4Error, TransportError
from epson_usb.printer import EpsonUsbPrinter

try:  # private helper of epson-usb (interface fallback for libusb)
    from epson_usb.printer import _connect_with_fallback
except ImportError:  # pragma: no cover - other library version
    _connect_with_fallback = None

__all__ = [
    "usb_printer",
    "UsbEpsonPrinterMixin",
    "RecoveringD4Session",
    "RobustUsbPrinter",
    "upstream_knows_model",
    "factory_kwargs",
]

log = logging.getLogger(__name__)

#: Where the trace of a failed USB handshake is written, for diagnosis.
DIAG_FILE = Path.home() / "Documents" / "EpsonServiceTool" / "usb_diagnose.log"

#: IEEE 1284.4 transaction "Exit": ends the D4 session, the printer goes back
#: to packet mode. Without it the printer stays in D4 after a session and the
#: *next* "@EJL 1284.4" + Init is not answered (the "D4 Init failed" error).
D4_EXIT = b"\x08"

#: Revisions tried, in order. 0x20 first (what epson-usb offers), then 0x10
#: directly (what the L3250 family and gutenprint use), because some firmware
#: does not answer an unknown revision at all instead of naming its own.
REVISIONS = (0x20, 0x10)


def _fmt(event) -> str:
    if isinstance(event, (bytes, bytearray)):
        return bytes(event).hex(" ")
    return str(event)


class RecoveringD4Session(EpsonCtrlSession):
    """``EpsonCtrlSession`` that survives a printer still sitting in D4 mode.

    Differences from the library session (whose byte stream is unchanged for
    the first attempt):

    * when the first handshake gets no answer, the session sends a D4 *Exit*,
      waits, enters D4 again and offers revision 0x10 and 0x20 explicitly;
    * :meth:`close` sends *Exit* before releasing the pipe, so the printer is
      back in packet mode for the next connection (the library only closes the
      handle, which leaves the printer in D4 until it is switched off).
    """

    def _handshake(self, revisions: Sequence[int]) -> Optional[int]:
        """Enter D4 and Init. Returns the accepted revision or ``None``."""
        self.drain()
        self.transport.write(D4_ENTER_SEQUENCE, self.timeouts.write_ms)
        self._trace(">", D4_ENTER_SEQUENCE)
        if self.timeouts.enter_pause_s:
            time.sleep(self.timeouts.enter_pause_s)
        self._trace("enter", self.recv(self.timeouts.enter_ms))
        tried = set()
        queue = list(revisions)
        while queue:
            rev = queue.pop(0)
            if rev in tried:
                continue
            tried.add(rev)
            self.send(0, 0, bytes([0x00, rev]), credit=1)
            reply = self.recv(self.timeouts.init_ms)
            payload = reply.payload if reply else b""
            self._trace("init", (hex(rev), _fmt(payload)))
            if len(payload) >= 3 and payload[0] == 0x80:
                if payload[1] == 0x00:
                    return rev
                if payload[2] and payload[2] not in tried:
                    queue.insert(0, payload[2])  # printer named its revision
        return None

    def _leave_d4(self) -> None:
        """Best effort: end a D4 session the printer may still be in."""
        try:
            self.drain()
            self.send(0, 0, D4_EXIT, credit=1)
            self._trace("exit", self.recv(1000))
            time.sleep(0.5)
            self.drain()
        except TransportError:
            raise
        except Exception as exc:  # pragma: no cover - defensive
            self._trace("exit-error", exc)

    def connect(self) -> int:
        attempts = (
            (False, REVISIONS[:1]),       # exactly what the library does
            (True, REVISIONS),            # Exit first, then 0x20 / 0x10
            (True, REVISIONS[::-1]),      # Exit again, 0x10 first
        )
        for send_exit, revisions in attempts:
            if send_exit:
                self._trace("recover", "D4 Exit + re-enter, revisions %s"
                            % ", ".join(hex(r) for r in revisions))
                self._leave_d4()
            rev = self._handshake(revisions)
            if rev is not None:
                self.rev = rev
                self._open_channel()
                self.connected = True
                return rev
        raise D4Error(
            "D4 Init failed (the printer did not answer D4). Tried revisions "
            "0x20 and 0x10, also after a D4 Exit."
        )

    def close(self) -> None:
        if self.connected:
            try:
                self.send(0, 0, D4_EXIT, credit=1)
                self.recv(800)
            except Exception:
                pass
        super().close()


def _sibling_paths(path: str) -> List[str]:
    """The same Windows USBPRINT path with the other ``mi_0x`` interfaces."""
    out = [path]
    if re.search(r"mi_0\d", path, re.IGNORECASE):
        for mi in ("mi_00", "mi_01", "mi_02"):
            candidate = re.sub(r"mi_0\d", mi, path, flags=re.IGNORECASE)
            if candidate.lower() not in (p.lower() for p in out):
                out.append(candidate)
    return out


_HINTS_DE = (
    "Der Drucker antwortet nicht auf das USB-Wartungsprotokoll (D4).\n"
    "Bitte nacheinander pruefen:\n"
    "  1. Drucker aus- und wieder einschalten (Netzschalter, ca. 10 s warten),\n"
    "     danach im Tool erneut 'Auslesen'.\n"
    "  2. Kein Druckauftrag in der Warteschlange, Drucker nicht im Fehlerzustand.\n"
    "  3. Epson-Software beenden, die den Drucker abfragt (EPSON Status Monitor,\n"
    "     Epson Printer Connection Checker, Epson Smart Panel usw.; auch im\n"
    "     Infobereich der Taskleiste).\n"
    "  4. Drucker direkt am PC anschliessen (kein USB-Hub / Docking-Station).\n"
    "  5. Alternativ den Drucker per Netzwerk (IP) ansprechen."
)


class RobustUsbPrinter(EpsonUsbPrinter):
    """``EpsonUsbPrinter`` with the D4 recovery above and interface fallback.

    On Windows the ``usbprint`` backend has a single pipe per path, so the
    library never tries another USB interface; here the sibling ``mi_0x``
    paths of the chosen device are tried too. A failed attempt writes its
    trace to :data:`DIAG_FILE`.
    """

    def __init__(self, *args, trace=None, **kwargs) -> None:
        self._events = deque(maxlen=400)
        self._user_trace = trace
        super().__init__(*args, trace=self._record, **kwargs)

    def _record(self, direction: str, event) -> None:
        self._events.append("%s %-10s %s" % (
            time.strftime("%H:%M:%S"), direction, _fmt(event)))
        if self._user_trace is not None:
            self._user_trace(direction, event)

    def _candidates(self) -> list:
        if self._transport_arg is not None:
            return [self._transport_arg]
        device = self._device
        if isinstance(device, str) and self._backend in (None, "usbprint"):
            return _sibling_paths(device)
        return [device]

    def _make_session(self, transport):
        return RecoveringD4Session(
            transport,
            read_key=self.read_key,
            write_key=self.write_key,
            timeouts=self._timeouts,
            trace=self._trace,
        )

    def open(self) -> "RobustUsbPrinter":
        if self.session is not None and self.session.connected:
            return self
        self.session = None
        errors = []
        for device in self._candidates():
            self._record("open", device)
            try:
                if isinstance(device, Transport):
                    transport = device
                    if not transport.opened:
                        transport.open()
                else:
                    transport = open_transport(
                        device,
                        backend=self._backend,
                        instance_id=self._instance_id,
                        **dict(self._transport_kwargs),
                    )
            except TransportError as exc:
                errors.append((device, exc))
                self._record("open-fail", exc)
                continue
            try:
                if _connect_with_fallback is not None:
                    session = _connect_with_fallback(
                        transport, lambda: self._make_session(transport), self.log)
                else:  # pragma: no cover
                    session = self._make_session(transport)
                    try:
                        session.connect()
                    except Exception:
                        session.close()
                        raise
            except (D4Error, TransportError) as exc:
                errors.append((device, exc))
                self._record("d4-fail", exc)
                continue
            self.session = session
            self.revision = session.rev
            self.log.info("connected: %s (D4 revision 0x%02x)",
                          transport.describe(), self.revision)
            return self
        raise self._failure(errors)

    def _failure(self, errors) -> Exception:
        details = "\n".join("  - %s: %s" % (d, e) for d, e in errors)
        diag = ""
        try:
            DIAG_FILE.parent.mkdir(parents=True, exist_ok=True)
            with open(DIAG_FILE, "a", encoding="utf-8") as fh:
                fh.write("==== %s ====\n" % time.strftime("%Y-%m-%d %H:%M:%S"))
                fh.write(details + "\n")
                fh.write("\n".join(self._events) + "\n\n")
            diag = "\nProtokoll: %s" % DIAG_FILE
        except OSError:
            pass
        only_open_errors = errors and all(
            not isinstance(e, D4Error) for _, e in errors)
        cls = TransportError if only_open_errors else D4Error
        first = str(errors[0][1]) if errors else "no device"
        return cls("%s\n\n%s\n\nVersucht:\n%s%s" % (first, _HINTS_DE, details, diag))


def upstream_knows_model(base, *names) -> bool:
    """Has the host usable parameters for this model already?

    "Usable" means the entry exists *and* carries a ``read_key`` -- an entry
    without one cannot reach the EEPROM, so a caller's own tables are then the
    only option rather than a replacement. This is the question a caller asks
    when deciding whether its own parameters are needed at all.
    """
    config = getattr(base, "PRINTER_CONFIG", None) or {}
    for name in names:
        if not name:
            continue
        entry = config.get(name)
        if isinstance(entry, dict) and "read_key" in entry:
            return True
    return False


def factory_kwargs(factory: Callable, available: Mapping[str, object],
                   host_identity: Sequence[str] = ("model", "printer")) -> dict:
    """The subset of ``available`` that ``factory`` is willing to receive.

    A factory is the caller's way of building the USB object with its own keys,
    so it may want to know *which model* it is serving -- something the default
    :class:`~epson_usb.printer.EpsonUsbPrinter` has no parameter for. Rather
    than passing everything (which would break on the first named parameter a
    factory does not declare) or nothing (which would make the hook useless),
    the factory receives the arguments it declares, plus -- when it takes
    ``**kwargs`` -- any other *transport* option the caller supplied (that is how
    ``usb_options={"config": ...}`` reaches a backend).

    ``host_identity`` names the arguments that are **not** transport options.
    They are passed only to a factory that declares them by name, because the
    default factory forwards unrecognised keywords to the transport: handing it
    ``model=`` sends that keyword all the way to the backend constructor and
    breaks device discovery ("__init__() got an unexpected keyword argument
    'model'") for every caller that does not pass a ready-made ``transport``.
    """
    try:
        parameters = inspect.signature(factory).parameters
    except (TypeError, ValueError):  # pragma: no cover - exotic callables
        return dict(available)
    accepts_kwargs = any(
        p.kind is inspect.Parameter.VAR_KEYWORD for p in parameters.values()
    )
    out = {}
    for name, value in available.items():
        if name in parameters:
            out[name] = value
        elif accepts_kwargs and name not in host_identity:
            out[name] = value
    return out


class UsbEpsonPrinterMixin:
    """Gives an ``EpsonPrinter`` subclass a USB transport instead of SNMP.

    Only :meth:`fetch_oid_values` is overridden. Everything the host calls above
    it -- including the EEPROM write path, which builds the write frame *and*
    its key obfuscation in the host -- therefore runs the host's own code.
    """

    #: ``{model name: host parm dict}``, supplied by the caller. ``None`` means
    #: "the host's own configuration is all there is", which is the normal,
    #: data-free case.
    usb_params: Optional[Mapping[str, dict]] = None

    #: Builds the :class:`~epson_usb.printer.EpsonUsbPrinter` used for the USB
    #: link. Override (or pass ``usb_factory=``) to create an object that holds
    #: keys: see the module docstring.
    usb_factory: Callable[..., EpsonUsbPrinter] = RobustUsbPrinter

    #: The USB side of the printer.
    usb: EpsonUsbPrinter

    def __init__(
        self,
        *args,
        usb_printer: Optional[EpsonUsbPrinter] = None,
        usb_model: Optional[str] = None,
        usb_params: Optional[Mapping[str, dict]] = None,
        usb_factory: Optional[Callable[..., EpsonUsbPrinter]] = None,
        usb_options: Optional[Mapping[str, object]] = None,
        device=None,
        backend: Optional[str] = None,
        instance_id: Optional[str] = None,
        interface: Optional[int] = None,
        transport=None,
        usb_timeouts=None,
        **kwargs,
    ) -> None:
        #: The model name the caller asked for (the host's own ``model``, or the
        #: ``usb_model`` spelling for callers that keep the two apart).
        self.usb_model = kwargs.get("model") or usb_model
        # Hand the caller's parameters to the host, if any. `setdefault` is
        # deliberate: an entry the host already has stays authoritative. The
        # requested name and every alias the caller registered are tried, so it
        # does not matter which spelling the caller used -- the host's own
        # `self.parm = PRINTER_CONFIG[self.model]` will find the entry.
        params = usb_params if usb_params is not None else type(self).usb_params
        if params:
            model_name = self.usb_model
            if model_name:
                conf_dict = dict(kwargs.get("conf_dict") or {})
                entry = params.get(model_name)
                if entry is not None:
                    conf_dict.setdefault(model_name, entry)
                    kwargs["conf_dict"] = conf_dict
                    log.debug("parameters for %s taken from the caller's tables",
                              model_name)
                else:
                    log.info(
                        "no caller-supplied parameters for %r; the host's own "
                        "configuration will be used", model_name,
                    )
        # hostname is deliberately left as the caller gave it (usually None):
        # the USB override never uses it, and `get_snmp_info` failing loudly is
        # more honest than silently using a wrong address.
        super().__init__(*args, **kwargs)
        factory = usb_factory or type(self).usb_factory
        if usb_printer is not None:
            self.usb = usb_printer
            return
        self.usb = factory(
            **factory_kwargs(
                factory,
                {
                    "device": device,
                    "backend": backend,
                    "instance_id": instance_id,
                    "transport": transport,
                    "timeouts": usb_timeouts,
                    "dry_run": getattr(self, "dry_run", False),
                    # Lazy, not at construction: the host builds printer objects
                    # for reasons that have nothing to do with the hardware --
                    # ui.py constructs one just to list the models in a
                    # dropdown. Opening a USB device there would be both wrong
                    # and fatal, so the device is touched on the first command.
                    "auto_open": False,
                    "lazy_open": True,
                    # Which printer this is, for a factory that keeps its own
                    # keys; and the host object itself, for one that needs it.
                    "model": self.usb_model,
                    "printer": self,
                    # Whatever else the caller needs to reach the device, such
                    # as {"config": MockConfig(...)} for the fake printer.
                    **(dict(usb_options) if usb_options else {}),
                    # The USB interface to pin, when the caller named one: it is
                    # the library's own ``interface=`` transport option. An
                    # unset one is not passed at all, because a transport that
                    # cannot take it refuses even ``interface=None``.
                    **(
                        {"interface": interface}
                        if interface is not None else {}
                    ),
                },
            )
        )

    # -- the one door ------------------------------------------------------
    def fetch_oid_values(self, oid, label: str = "unknown"):
        """Answer an OID over USB (was: SNMP GET).

        Same return contract as the host: a list of ``(type_name, value)``,
        ``[(None, False)]`` when the OID is not an EPSON-CTRL message or the
        printer answered nothing usable.

        Connection failures are the one exception, and they follow the host
        rather than swallowing the error: when the printer cannot be reached at
        all -- no device, handshake refused, cable unplugged -- the host raises
        ``TimeoutError`` (its ``RequestTimedOut``), so this does too, with the
        USB detail in the message and the original exception as ``__cause__``.
        A user then learns that the printer is missing instead of seeing every
        value silently become ``None``. The library's own API
        (:class:`~epson_usb.printer.EpsonUsbPrinter`) keeps the typed errors.
        """
        if getattr(self, "mib_dict", None):
            # Config-file replay mode: the host answers from the recorded
            # dictionary, which has nothing to do with USB.
            return super().fetch_oid_values(oid, label=label)
        try:
            return self.usb.fetch_oid_values(oid, label=label)
        except (TransportError, D4Error) as exc:
            # The device could not be opened, or it did not answer the D4
            # handshake: that is the connection failing, which is what the
            # docstring above promises to report. Since epson-usb 0.1.2 the
            # handshake is also where a pinned interface that stays silent
            # gives up, and saying so beats answering None for every OID.
            raise TimeoutError("USB: %s" % exc) from exc
        except Exception as exc:  # pragma: no cover - defensive
            log.error("USB request failed (%s): %s", label, exc)
            return [(None, False)]

    # -- lifecycle ---------------------------------------------------------
    def close(self) -> None:
        """Release the USB device (the host has no such method; harmless)."""
        try:
            self.usb.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *exc_info) -> None:
        self.close()

    def usb_describe(self) -> str:
        return self.usb.describe()

    # -- things USB cannot do ---------------------------------------------
    def _needs_network(self, what: str):
        raise NotImplementedError(
            "%s sends data through LPR to a network address, which the USB "
            "transport does not implement. Use the SNMP/LPR path, or print "
            "through the operating system's printer queue." % what
        )

    def print_check_nozzles(self, *args, **kwargs):  # pragma: no cover
        self._needs_network("print_check_nozzles")

    def print_test_color_pattern(self, *args, **kwargs):  # pragma: no cover
        self._needs_network("print_test_color_pattern")

    def print_clean_nozzles(self, *args, **kwargs):  # pragma: no cover
        self._needs_network("print_clean_nozzles")


def usb_printer(base=None, name: Optional[str] = None,
                params: Optional[Mapping[str, dict]] = None,
                factory: Optional[Callable[..., EpsonUsbPrinter]] = None,
                **class_kwargs) -> Type:
    """Build (and return) an ``EpsonPrinter`` subclass whose transport is USB.

    ::

        UsbEpsonPrinter = usb_printer(EpsonPrinter)      # the host class

    ``base`` is required: this module is reached *from* the host program, so the
    class to extend is always at hand. Passing no class is an error rather than
    an invitation to go looking for one by module name.

    ``params`` and ``factory`` are the two hooks described in the module
    docstring; both are optional and neither carries data of its own.

    The result is an ordinary class: it can be subclassed again, instantiated
    many times, and its instances are ``isinstance(..., EpsonPrinter)``, so code
    that type-checks or calls host methods keeps working.
    """
    if base is None:
        raise TypeError(
            "usb_printer() needs the class to extend: usb_printer(EpsonPrinter)"
        )
    namespace_name = name or ("Usb" + base.__name__)
    namespace = {
        "__module__": __name__,
        "__doc__": UsbEpsonPrinterMixin.__doc__,
    }
    if params is not None:
        namespace["usb_params"] = params
    if factory is not None:
        namespace["usb_factory"] = staticmethod(factory)
    namespace.update(class_kwargs)
    return type(namespace_name, (UsbEpsonPrinterMixin, base), namespace)
