"""
Automatische Modellerkennung fuer ui.py (Drucker-Tankwart-Ausgabe).

Ircamas Oberflaeche erkennt das Modell nur, wenn die Netzwerksuche genau
einen Drucker findet; bei USB muss es immer von Hand gewaehlt werden. Hier
wird das Modell zusaetzlich erkannt:

  * USB: nach "Drucker suchen" und bei Wahl eines USB-Anschlusses, ueber die
    Geraetekennung (di: MDL/DES), die der Drucker meldet;
  * Netzwerk: sobald eine gueltige IP-Adresse eingetragen ist (Enter oder
    Feld verlassen), ueber die SNMP-Abfrage des Modellnamens.

Verwendung (ui.py, nach der Klasse EpsonPrinterUI)::

    tankwart_auto.install(EpsonPrinterUI)
"""
import logging
import tkinter as tk

import zusatz_drucker
from epson_print_conf import EpsonPrinter


def _status(self, tag, text):
    prefix = {"info": "[INFO]", "warn": "[WARNUNG]", "error": "[FEHLER]"}[tag]
    try:
        self.show_status_text_view()
        self.status_text.insert(tk.END, prefix, tag)
        self.status_text.insert(tk.END, " " + text + "\n")
        self.status_text.see(tk.END)
    except Exception:
        pass


def _connection_key(self):
    if self.usb_mode():
        return ("usb", self.usb_port_var.get())
    return ("ip", self.ip_var.get().strip())


def auto_detect_model(self, force=False):
    """Modell beim angeschlossenen Drucker abfragen und einstellen."""
    if self.model_var.get() and not force:
        return
    usb = self.usb_mode()
    ip = self.ip_var.get().strip()
    if not usb and not self._connection_ready(ip):
        return
    key = _connection_key(self)
    if not force and getattr(self, "_auto_last_key", None) == key:
        return
    self._auto_last_key = key
    self.config(cursor="watch")
    self.update_idletasks()
    printer = None
    try:
        printer_cls = self.printer_class()
        kwargs = dict(conf_dict=self.conf_dict, replace_conf=self.replace_conf)
        if usb:
            backend, device = self.selected_usb_port()
            if device:
                kwargs.update(backend=backend, device=device)
        else:
            kwargs["hostname"] = ip
        printer = printer_cls(**kwargs)
        if usb:
            ident = printer.get_device_identification() or {}
            name = ident.get("Model") or ident.get("Description")
        else:
            info = printer.get_snmp_info("Model") or {}
            name = info.get("Model")
        if isinstance(name, (list, tuple)):
            name = name[0] if name else None
        valid = EpsonPrinter(
            conf_dict=self.conf_dict, replace_conf=self.replace_conf
        ).valid_printers
        match = zusatz_drucker.finde_modell(name, valid)
        if match:
            self.model_var.set(match)
            _status(self, "info", "Modell erkannt: %s (Drucker meldet '%s')."
                    % (match, name))
        elif name:
            _status(self, "warn", "Drucker meldet '%s' - dieses Modell ist "
                    "nicht in der Datenbank. Bitte Modell von Hand wählen."
                    % name)
        else:
            _status(self, "warn", "Modell nicht erkannt: keine Antwort vom "
                    "Drucker. Bitte Modell von Hand wählen.")
    except Exception as exc:
        logging.debug("Modellerkennung fehlgeschlagen: %s", exc)
        _status(self, "warn", "Modell nicht erkannt (%s). Bitte Modell von "
                "Hand wählen." % exc)
    finally:
        close = getattr(printer, "close", None)
        if close:
            try:
                close()
            except Exception:
                pass
        self.config(cursor="")


def install(cls):
    """Erkennung in die Klasse EpsonPrinterUI einhaengen."""
    cls.auto_detect_model = auto_detect_model

    original_usb = cls.detect_usb_devices

    def detect_usb_devices(self):
        original_usb(self)
        if getattr(self, "usb_port_map", None) is not None:
            auto_detect_model(self, force=True)

    cls.detect_usb_devices = detect_usb_devices

    original_scan = cls.detect_printers_thread

    def detect_printers_thread(self, cursor=True):
        result = original_scan(self, cursor)
        # cursor=False ist der eigentliche Durchlauf (cursor=True plant ihn nur)
        if not cursor and not self.usb_mode() and not self.model_var.get():
            auto_detect_model(self)
        return result

    cls.detect_printers_thread = detect_printers_thread

    original_init = cls.__init__

    def __init__(self, *args, **kwargs):
        original_init(self, *args, **kwargs)

        def on_ip(event=None):
            auto_detect_model(self, force=False if self.model_var.get() == ""
                              else _connection_key(self) != getattr(
                                  self, "_auto_last_key", None))

        try:
            self.ip_entry.bind("<Return>", on_ip, "+")
            self.ip_entry.bind("<FocusOut>", on_ip, "+")
        except Exception:
            pass
        try:
            self.usb_port_dropdown.bind(
                "<<ComboboxSelected>>",
                lambda e: auto_detect_model(self, force=True), "+")
        except Exception:
            pass

    cls.__init__ = __init__
