@echo off
rem Drucker Tankwart - Epson Printer Configuration starten
cd /d "%~dp0"
set PY=
set LOCALPY=%LOCALAPPDATA%\Programs\Python\Python313\python.exe
where py >nul 2>nul && set PY=py -3
if not defined PY if exist "%LOCALPY%" set PY="%LOCALPY%"
if not defined PY python -c "import sys" >nul 2>nul && set PY=python
if not defined PY (
  echo Python 3 wurde nicht gefunden.
  echo Bitte zuerst python_installieren.bat im Ordner EpsonServiceTool ausfuehren.
  pause
  exit /b 1
)
if not exist .venv\Scripts\python.exe (
  echo Erster Start: richte Umgebung ein ...
  %PY% -m venv .venv || (pause & exit /b 1)
  .venv\Scripts\python -m pip install -q --upgrade pip
  .venv\Scripts\python -m pip install -q -r requirements.txt || (echo Installation fehlgeschlagen. & pause & exit /b 1)
)
start "" .venv\Scripts\pythonw.exe ui.py
