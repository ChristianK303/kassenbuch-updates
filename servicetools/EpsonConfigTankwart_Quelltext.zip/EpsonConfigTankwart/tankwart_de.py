"""
Deutsche Oberfläche für epson_print_conf (ui.py) - Drucker-Tankwart-Ausgabe.

Statt jeden Text in ui.py umzuschreiben, werden die Texte übersetzt, wenn
Tk sie anzeigt: Beschriftungen und Buttons (``text=``), Menüs (``label=``),
Fenstertitel, Meldungsfenster, Dateidialoge, Spaltenköpfe und die
Statusmeldungen. ui.py bleibt so fast unverändert und Updates von Ircama
lassen sich weiter einspielen.

Verwendung (ui.py)::

    import tankwart_de
    tankwart_de.install()                       # vor dem Aufbau der Fenster
    tankwart_de.wrap_text_widget(self.status_text)

Was nicht im Wörterbuch steht, bleibt englisch. Mit der Umgebungsvariablen
``TANKWART_DE_FEHLEND=<datei>`` werden solche Texte in die Datei geschrieben,
um das Wörterbuch zu ergänzen.

Bewusst NICHT übersetzt: Werte von Auswahllisten (``values``), weil ui.py
sie mit festen englischen Texten vergleicht; Daten des Druckers
(Statusschlüssel, Modellnamen) und die Python-Konsole.
"""
import os
import re
import tkinter
from tkinter import messagebox, ttk

# ---------------------------------------------------------------------------
# Feste Texte (englisch -> deutsch). Schlüssel ohne führende/abschliessende
# Leerzeichen und Zeilenumbrüche; die werden beim Übersetzen beibehalten.
# ---------------------------------------------------------------------------
DE = {
    # Menüs
    "File": "Datei",
    "Settings": "Einstellungen",
    "Help": "Hilfe",
    "Load a PICKLE printer configuration file or web URL...":
        "PICKLE-Druckerkonfiguration laden (Datei oder Web-Adresse)...",
    "Import a XML printer configuration file or web URL...":
        "XML-Druckerkonfiguration importieren (Datei oder Web-Adresse)...",
    "Import a TOML printer configuration file or web URL...":
        "TOML-Druckerkonfiguration importieren (Datei oder Web-Adresse)...",
    "Save the selected printer configuration to a PICKLE file...":
        "Ausgewählte Druckerkonfiguration als PICKLE-Datei speichern...",
    "Quit Application": "Programm beenden",
    "Show printer parameters of the selected model":
        "Druckerparameter des gewählten Modells anzeigen",
    "Show printer keys of the selected model":
        "Schlüssel des gewählten Modells anzeigen",
    "Keep only selected printer configuration":
        "Nur die gewählte Druckerkonfiguration behalten",
    "Clear printer list": "Druckerliste leeren",
    "Interactive Console (API Playground)":
        "Interaktive Konsole (API-Spielwiese)",
    "Remove selected printer configuration":
        "Gewählte Druckerkonfiguration entfernen",
    "Get next local IP addresss": "Nächste lokale IP-Adresse holen",
    "Usage guide": "Bedienungsanleitung",
    "Program Information": "Programminformation",

    # Hauptfenster: Rahmen und Beschriftungen
    "Printer Model": "Druckermodell",
    "Model:": "Modell:",
    "Printer Connection": "Verbindung zum Drucker",
    "TCP/IP": "Netzwerk (TCP/IP)",
    "USB": "USB",
    "IP Address:": "IP-Adresse:",
    "USB Port:": "USB-Anschluss:",
    "Power-off Timer (minutes)": "Abschalt-Timer (Minuten)",
    "TI Received Time (date)": "Datum der Erstinbetriebnahme",
    "WiFi MAC Address": "WLAN-MAC-Adresse",
    "Printer Serial Number": "Seriennummer des Druckers",
    "Get": "Lesen",
    "Set": "Setzen",
    "Status": "Status",

    # Buttons
    "Printer\nStatus": "Drucker-\nstatus",
    "Printer\nWeb Interface": "Web-Oberfläche\ndes Druckers",
    "Clean\nNozzles": "Düsen\nreinigen",
    "Detect\nConfiguration": "Konfiguration\nerkennen",
    "Temporary Reset\nWaste Ink Levels": "Resttinte\nvorübergehend frei",
    "Detect\nPrinters": "Drucker\nsuchen",
    "Detect\nAccess Keys": "Zugangs-\nschlüssel finden",
    "Print\nTests": "Test-\ndrucke",
    "Read\nEEPROM": "EEPROM\nlesen",
    "Write\nEEPROM": "EEPROM\nschreiben",
    "Reset Waste\nInk Levels": "Resttinten-\nzähler zurücksetzen",

    # Tooltips
    "Search among available printer models":
        "In den verfügbaren Druckermodellen suchen",
    "Select the model of the printer, or press 'Detect Printers'. Special "
    "features are allowed via F2, F3, F5, F6, F8, F9.":
        "Druckermodell auswählen oder 'Drucker suchen' drücken. "
        "Sonderfunktionen über F2, F3, F5, F6, F8, F9.",
    "TCP/IP (SNMP): talk to the printer over the network, wrapping every "
    "EPSON-CTRL command in an SNMP request.":
        "Netzwerk (SNMP): Der Drucker wird über das Netzwerk angesprochen, "
        "jeder EPSON-CTRL-Befehl wird in eine SNMP-Anfrage verpackt.",
    "USB (IEEE 1284.4 / D4): talk to the printer over the USB cable. Needed "
    "by the models whose firmware refuses EEPROM access over SNMP. No IP "
    "address is used, and the features that need the network (web interface, "
    "LPR printing, SNMP-only values) are disabled.":
        "USB (IEEE 1284.4 / D4): Der Drucker wird über das USB-Kabel "
        "angesprochen. Nötig bei Modellen, deren Firmware den EEPROM-Zugriff "
        "per Netzwerk sperrt. Es wird keine IP-Adresse benutzt; Funktionen, "
        "die das Netzwerk brauchen (Web-Oberfläche, Drucken per LPR, "
        "reine SNMP-Werte), sind abgeschaltet.",
    "Enter the IP address, or press 'Detect Printers' (you can also enter "
    "part of the IP address to speed up the detection), or press F9 more "
    "times to get the next local IP address, which can then be edited (by "
    "removing the last part before pressing 'Detect Printers').\n"
    "Not used in USB mode.":
        "IP-Adresse eingeben oder 'Drucker suchen' drücken (ein Teil der "
        "IP-Adresse beschleunigt die Suche). Mit F9 die nächste lokale "
        "IP-Adresse holen und anpassen (letzten Teil entfernen, dann "
        "'Drucker suchen').\nBei USB nicht benutzt.",
    "The USB devices found on this machine, listed when this box appears and "
    "by the button next to it.\nLeave the first entry selected to let the "
    "library pick the device (its default backend order), or pin one of the "
    "listed devices -- needed when several printers are attached, or when the "
    "first interface of a multi-interface device does not answer.\nThe chosen "
    "device is passed to the transport as backend/device, the same options "
    "the --backend/--device command line uses.":
        "Die an diesem PC gefundenen USB-Geräte (aktualisiert über den "
        "Knopf daneben).\nErsten Eintrag lassen, damit das Programm das Gerät "
        "selbst wählt, oder ein Gerät fest auswählen - nötig bei mehreren "
        "Druckern oder wenn die erste Schnittstelle nicht antwortet.",
    "Scan the USB bus again and refill the list":
        "USB erneut durchsuchen und Liste aktualisieren",
    "Enter a number of minutes.": "Anzahl Minuten eingeben.",
    "Enter a valid date with format YYYY-MM-DD.":
        "Gültiges Datum im Format JJJJ-MM-TT eingeben.",
    "Enter Enter a valid MAC address (6 hex octets optionally separated by "
    "dash).":
        "Gültige MAC-Adresse eingeben (6 Hex-Bytes, optional mit "
        "Bindestrich getrennt).",
    "Enter Enter a valid printer serial number (10 uppercase or numeric "
    "characters).":
        "Gültige Seriennummer eingeben (10 Großbuchstaben oder Ziffern).",
    "Scan the network for printers (TCP/IP mode), or list the USB devices the "
    "library can see (USB mode).":
        "Netzwerk nach Druckern durchsuchen (Netzwerk-Modus) oder die "
        "erkannten USB-Geräte auflisten (USB-Modus).",

    # Hinweise der Funktionsknöpfe (FEATURE_TOOLTIPS in ui.py)
    "Read the printer status: ink and maintenance box levels, paper, errors.":
        "Druckerstatus lesen: Tintenstände, Wartungsbox, Papier, Fehler.",
    "Open the printer web interface in the browser.":
        "Die Web-Oberfläche des Druckers im Browser öffnen.",
    "Run a nozzle cleaning cycle on the selected group, optionally with a "
    "power clean.":
        "Eine Düsenreinigung für die gewählte Düsengruppe starten, auf Wunsch "
        "als Intensivreinigung.",
    "Print the nozzle check, the colour pattern and the paper-feed tests.":
        "Düsentest, Farbmuster und Papiertransport-Tests drucken.",
    "Read the printer values and dump the EEPROM, then list the addresses "
    "where each value is stored.":
        "Druckerwerte und EEPROM auslesen und anzeigen, an welchen Adressen "
        "die Werte gespeichert sind.",
    "Brute-force the read_key, then validate the write_key against the "
    "serial number.":
        "Den Lese-Schlüssel (read_key) durch Ausprobieren finden und dann den "
        "Schreib-Schlüssel (write_key) anhand der Seriennummer prüfen.",
    "Temporarily reset the ink waste counter (until the next power cycle), "
    "with the rw service command.":
        "Den Resttintenzähler vorübergehend freigeben (bis zum nächsten "
        "Aus- und Einschalten), mit dem Servicebefehl rw.",
    "Search for printers: SNMP broadcast over the network, or the USB devices "
    "found on this machine.":
        "Drucker suchen: im Netzwerk (SNMP) oder die an diesem PC "
        "angeschlossenen USB-Geräte.",
    "Read a list of EEPROM addresses.": "Eine Liste von EEPROM-Adressen lesen.",
    "Write values to EEPROM addresses.": "Werte in EEPROM-Adressen schreiben.",
    "Reset the ink waste counters to zero, writing every cell the printer "
    "model keeps them in.":
        "Die Resttintenzähler auf null setzen; dabei werden alle Speicherzellen "
        "beschrieben, in denen das Modell sie ablegt.",
    "The printer web interface is reached over the network: select TCP/IP "
    "(SNMP) to open it in the browser.":
        "Die Web-Oberfläche ist nur über das Netzwerk erreichbar: zum Öffnen "
        "Netzwerk (TCP/IP) wählen.",
    "Cleaning the nozzles prints through LPR over the network: select TCP/IP, "
    "or clean the nozzles from the printer's own queue.":
        "Die Düsenreinigung läuft als Druckauftrag über das Netzwerk (LPR): "
        "Netzwerk (TCP/IP) wählen oder die Reinigung über die "
        "Windows-Druckerwarteschlange starten.",
    "The print tests are sent through LPR over the network: select TCP/IP, or "
    "print from the printer's own queue.":
        "Testdrucke laufen über das Netzwerk (LPR): Netzwerk (TCP/IP) wählen "
        "oder über die Windows-Druckerwarteschlange drucken.",
    "Ensure you really want this before pressing this key.":
        "Nur drücken, wenn Sie das wirklich wollen.",

    # Kontextmenüs
    "Clear All": "Alles löschen",
    "Copy": "Kopieren",
    "Copy all text": "Gesamten Text kopieren",
    "Print all text": "Gesamten Text drucken",
    "Switch to tree view": "Zur Baumansicht wechseln",
    "Copy this item": "Diesen Eintrag kopieren",
    "Copy all items": "Alle Einträge kopieren",
    "Print all items": "Alle Einträge drucken",
    "Switch to text status": "Zur Textansicht wechseln",
    "Print items": "Einträge drucken",

    # Fenster, Dialoge
    "PICKLE file name": "Name der PICKLE-Datei",
    "Epson Printer Configuration Interactive Console (API Playground)":
        "Epson Printer Configuration - Interaktive Konsole (API-Spielwiese)",
    "Search Printer Models": "Druckermodelle suchen",
    "Search:": "Suche:",
    "Select": "Auswählen",
    "Critical operation": "Kritischer Vorgang",
    "After the change is applied, restarting the printer is required for "
    "this change to take effect.\n\nWarning: this is a dangerous operation.\n"
    "Continue only if you are very sure of what you do.":
        "Nach der Änderung muss der Drucker neu gestartet werden, damit sie "
        "wirksam wird.\n\nWarnung: Das ist ein gefährlicher Vorgang.\n"
        "Nur fortfahren, wenn Sie genau wissen, was Sie tun.",
    "Detect Access Keys - Confirm Action":
        "Zugangsschlüssel finden - Bestätigung",
    "Warning: this is a brute force operation, which takes several\nminutes "
    "to complete.\n\nResults will be shown in the status box.\n\nMake sure "
    "not to switch off the printer while the process is running and disable "
    "the auto power-off timer.\n\nBefore you proceed, consider finding the "
    "access keys of your\nprinter with the printer configuration database "
    "import\nprocedures described in the help (File menu: 'Import a XML'\nand "
    "'Import a TOML', which also accept a web URL): a\nconfiguration that "
    "already carries the access keys makes this\noperation unnecessary.\n\n"
    "Are you sure you want to proceed?":
        "Warnung: Hier werden alle Möglichkeiten durchprobiert, das dauert "
        "mehrere Minuten.\n\nDie Ergebnisse erscheinen im Statusfeld.\n\n"
        "Den Drucker währenddessen nicht ausschalten und den automatischen "
        "Abschalt-Timer deaktivieren.\n\nVorher prüfen, ob die Schlüssel "
        "schon über den Import einer Druckerdatenbank zu bekommen sind "
        "(Menü Datei: XML bzw. TOML importieren, auch per Web-Adresse); "
        "dann ist dieser Vorgang unnötig.\n\nWirklich fortfahren?",
    "Status Information": "Statusinformationen",
    "Printer parameters": "Druckerparameter",
    "Values of the keys from the printer configuration":
        "Schlüsselwerte aus der Druckerkonfiguration",
    "Printer configuration": "Druckerkonfiguration",
    "Print Test Options": "Testdruck-Optionen",
    "Select test:": "Test auswählen:",
    "Number of tests:": "Anzahl:",
    "Print tests": "Testdrucke",
    "Clean Nozzles Options": "Düsenreinigung - Optionen",
    "Select Nozzle Group:": "Düsengruppe auswählen:",
    "Power Clean": "Intensivreinigung",
    "Confirm": "Bestätigen",
    "Cancel": "Abbrechen",
    "Invalid Input for Read EEPROM": "Ungültige Eingabe für EEPROM lesen",
    "Please enter a valid list of integers.":
        "Bitte eine gültige Liste ganzer Zahlen eingeben.",
    "Invalid input for Write EEPROM":
        "Ungültige Eingabe für EEPROM schreiben",
    "Please enter a valid comma-separated sequence of 'address: value', like "
    "24: 0, 25: 0, 30: 0 using decimal numbers.":
        "Bitte 'Adresse: Wert'-Paare mit Komma getrennt eingeben, z. B. "
        "24: 0, 25: 0, 30: 0 (Dezimalzahlen).",
    "Feature not defined in the printer configuration.":
        "Funktion in der Druckerkonfiguration nicht definiert.",
    "Select the printer first.": "Bitte zuerst den Drucker auswählen.",
    "USB is not available: the epson-usb package is not installed. Install "
    "it with 'pip install epson-usb' (Python 3.10 or later).":
        "USB ist nicht verfügbar: Das Paket epson-usb ist nicht installiert "
        "(pip install epson-usb).",

    # Präfixe im Statusfeld
    "[ERROR]": "[FEHLER]",
    "[WARNING]": "[WARNUNG]",
    "[INFO]": "[INFO]",
    "[NOTE]": "[HINWEIS]",

    # Statusmeldungen
    ": Unknown printer model.": ": Unbekanntes Druckermodell.",
    ": No printer configuration defined.":
        ": Keine Druckerkonfiguration definiert.",
    "File save operation aborted.": "Speichern abgebrochen.",
    "File save operation failed.": "Speichern fehlgeschlagen.",
    "File load operation aborted.": "Laden abgebrochen.",
    "Converting file, please wait...": "Datei wird umgewandelt, bitte warten...",
    "Select a valid printer model.": "Bitte ein gültiges Druckermodell wählen.",
    "Printer list cleared.": "Druckerliste geleert.",
    "The browser is being opened.": "Der Browser wird geöffnet.",
    "Interrupted: the operation was stopped.":
        "Unterbrochen: Der Vorgang wurde gestoppt.",
    "Printer is unreachable or offline.":
        "Drucker ist nicht erreichbar oder ausgeschaltet.",
    "Printer unreachable or offline.":
        "Drucker nicht erreichbar oder ausgeschaltet.",
    "Missing 'Power off timer' in configuration":
        "'Abschalt-Timer' fehlt in der Konfiguration",
    "Improper values in printer serial number.":
        "Ungültige Werte in der Seriennummer.",
    "Cannot retrieve the printer serial number.":
        "Seriennummer kann nicht gelesen werden.",
    "Cannot retrieve the printer serial number. Possibly a printer firmware "
    "update disabled the operation.":
        "Seriennummer kann nicht gelesen werden. Möglicherweise hat ein "
        "Firmware-Update den Vorgang gesperrt.",
    "Cannot retrieve the printer WiFi MAC address.":
        "WLAN-MAC-Adresse kann nicht gelesen werden.",
    "Please Use a valid value for minutes.":
        "Bitte einen gültigen Minutenwert eingeben.",
    "Set Power off timer aborted.": "Setzen des Abschalt-Timers abgebrochen.",
    "Please Use a valid MAC address.": "Bitte eine gültige MAC-Adresse eingeben.",
    "Operation aborted.": "Vorgang abgebrochen.",
    "Write operation failed.": "Schreiben fehlgeschlagen.",
    "Please Use a valid serial number.":
        "Bitte eine gültige Seriennummer eingeben.",
    "Changing the WiFi MAC address of the printer. Restarting the printer is "
    "required for this change to take effect.":
        "WLAN-MAC-Adresse wird geändert. Der Drucker muss danach neu "
        "gestartet werden.",
    "Changing the serial number of the printer. Restarting the printer is "
    "required for this change to take effect.":
        "Seriennummer wird geändert. Der Drucker muss danach neu gestartet "
        "werden.",
    "Missing 'First TI received time' in configuration":
        "'Datum der Erstinbetriebnahme' fehlt in der Konfiguration",
    "No data from 'First TI received time'. Check printer configuration. "
    "Possibly a printer firmware update disabled the operation.":
        "Keine Daten für 'Datum der Erstinbetriebnahme'. Druckerkonfiguration "
        "prüfen. Möglicherweise hat ein Firmware-Update den Vorgang gesperrt.",
    "Please enter a valid date with format YYYY-MM-DD.":
        "Bitte ein gültiges Datum im Format JJJJ-MM-TT eingeben.",
    "Change of 'First TI received time' aborted.":
        "Ändern des Datums der Erstinbetriebnahme abgebrochen.",
    "Write operation failed: the printer refused one of the two cells of the "
    "power-off timer.":
        "Schreiben fehlgeschlagen: Der Drucker hat eine der beiden Zellen des "
        "Abschalt-Timers abgelehnt.",
    "Write operation failed: the printer refused one of the two cells of the "
    "received time.":
        "Schreiben fehlgeschlagen: Der Drucker hat eine der beiden Zellen des "
        "Datums abgelehnt.",
    "Please enter a valid IP address, or press 'Detect Printers'.":
        "Bitte eine gültige IP-Adresse eingeben oder 'Drucker suchen' "
        "drücken.",
    "Detecting the read_key...": "Lese-Schlüssel (read_key) wird gesucht...",
    "Detecting the serial number...": "Seriennummer wird gesucht...",
    "Detecting the write_key, do not power off the printer now...":
        "Schreib-Schlüssel (write_key) wird gesucht, Drucker jetzt nicht "
        "ausschalten...",
    "Could not detect read_key: either the printer did not answer (check the "
    "transport) or no key was accepted. The console reports which of the two "
    "happened.":
        "Lese-Schlüssel nicht gefunden: Entweder hat der Drucker nicht "
        "geantwortet (Verbindung prüfen) oder kein Schlüssel passte. Die "
        "Konsole zeigt, welcher Fall vorliegt.",
    "Cannot detect the serial number.": "Seriennummer nicht erkennbar.",
    "Could not detect serial number.": "Seriennummer nicht gefunden.",
    "More than one pattern appears to be a serial number with different "
    "values:":
        "Mehrere Stellen sehen wie eine Seriennummer mit verschiedenen "
        "Werten aus:",
    "Write operation failed. Check whether the serial number is changed and "
    "restore it manually.":
        "Schreiben fehlgeschlagen. Prüfen, ob sich die Seriennummer geändert "
        "hat, und sie ggf. von Hand wiederherstellen.",
    "Operation interrupted with errors.": "Vorgang mit Fehlern abgebrochen.",
    "Detect operation completed.": "Suche abgeschlossen.",
    "Unable to detect the write key by validating against any of the known "
    "ones.":
        "Schreib-Schlüssel nicht gefunden: Keiner der bekannten Schlüssel "
        "passte.",
    "Each candidate was tried by writing an EEPROM byte and reading it back: "
    "no write took effect on this printer with any of them. The console log "
    "names the address that did not change.":
        "Jeder Kandidat wurde durch Schreiben und Zurücklesen eines "
        "EEPROM-Bytes geprüft: Bei keinem hat das Schreiben gewirkt. Das "
        "Konsolenprotokoll nennt die unveränderte Adresse.",
    "Starting the access key detection, please wait for many minutes...":
        "Suche nach den Zugangsschlüsseln startet, das dauert viele "
        "Minuten...",
    "Press Ctrl+C to stop it; the status box reports progress.":
        "Mit Strg+C abbrechen; das Statusfeld zeigt den Fortschritt.",
    "Detection interrupted by the user.": "Suche vom Benutzer abgebrochen.",
    "Detect access key aborted.": "Schlüsselsuche abgebrochen.",
    "The printer web interface is reached over the network: select TCP/IP.":
        "Die Web-Oberfläche ist nur über das Netzwerk erreichbar: bitte "
        "Netzwerk (TCP/IP) wählen.",
    "[ERROR] Print tests need the network (TCP/IP): select it instead of USB.":
        "[FEHLER] Testdrucke brauchen das Netzwerk: bitte Netzwerk (TCP/IP) "
        "statt USB wählen.",
    "[ERROR] Invalid IP address.": "[FEHLER] Ungültige IP-Adresse.",
    "[ERROR] Printer unreachable or offline.":
        "[FEHLER] Drucker nicht erreichbar oder ausgeschaltet.",
    "[ERROR] Printing goes through LPR to a network address: select TCP/IP "
    "instead of USB.":
        "[FEHLER] Gedruckt wird per LPR über das Netzwerk: bitte Netzwerk "
        "(TCP/IP) statt USB wählen.",
    "Print test aborted by user.": "Testdruck vom Benutzer abgebrochen.",
    "Standard nozzle test printed.": "Standard-Düsentest gedruckt.",
    "Alternative nozzle test printed.": "Alternativer Düsentest gedruckt.",
    "Color pattern printed.": "Farbmuster gedruckt.",
    "Paper movement executed.": "Papiertransport ausgeführt.",
    "Cleaning the nozzles is executed by printing through LPR: select TCP/IP.":
        "Die Düsenreinigung läuft als Druckauftrag per LPR: bitte Netzwerk "
        "(TCP/IP) wählen.",
    "Nozzles cleaning operation aborted by user.":
        "Düsenreinigung vom Benutzer abgebrochen.",
    "clean_nozzles internal error.": "Interner Fehler bei der Düsenreinigung.",
    "Initiated cleaning of nozzles.": "Düsenreinigung gestartet.",
    "Reading the printer values (MIB over SNMP, device identification and "
    "EEPROM over USB)...":
        "Druckerwerte werden gelesen...",
    "No SNMP values could be found.": "Keine SNMP-Werte gefunden.",
    "Reading EEPROM values, please wait for some minutes...":
        "EEPROM wird gelesen, bitte einige Minuten warten...",
    "Cannot read EEPROM values: invalid printer model selected. Possibly a "
    "printer firmware update disabled the operation.":
        "EEPROM nicht lesbar: falsches Druckermodell gewählt. Möglicherweise "
        "hat ein Firmware-Update den Vorgang gesperrt.",
    "Analyzing EEPROM values...": "EEPROM-Werte werden ausgewertet...",
    "Operation completed.": "Vorgang abgeschlossen.",
    "Write EEPROM aborted.": "EEPROM schreiben abgebrochen.",
    "Waste ink levels reset aborted.":
        "Zurücksetzen der Resttintenzähler abgebrochen.",
    "Waste ink reset did not complete. A required read, write or "
    "verification failed, or the reset configuration is unsupported. See the "
    "console log.":
        "Zurücksetzen der Resttintenzähler nicht abgeschlossen: Lesen, "
        "Schreiben oder Prüfen ist fehlgeschlagen oder die Konfiguration wird "
        "nicht unterstützt. Siehe Konsolenprotokoll.",
    "Waste ink levels have been temporarily bypassed. You can now print.":
        "Resttintenzähler vorübergehend freigegeben. Sie können jetzt "
        "drucken.",
    "Failed to perform the temporary bypass of the waste ink levels.":
        "Vorübergehende Freigabe der Resttintenzähler fehlgeschlagen.",
    "Temporary bypass of the waste ink levels aborted.":
        "Vorübergehende Freigabe der Resttintenzähler abgebrochen.",
    "Detecting printers... (this might take a while)":
        "Drucker werden gesucht... (das kann etwas dauern)",
    "Printer model unknown.": "Druckermodell unbekannt.",
    "No printers found.": "Keine Drucker gefunden.",
    "USB environment:": "USB-Umgebung:",
    "No Epson USB printer found.": "Kein Epson-USB-Drucker gefunden.",
    "Select the printer model: the device is opened on the first command "
    "sent.":
        "Druckermodell wählen: Das Gerät wird beim ersten Befehl geöffnet.",
    "Cannot use the USB transport: the epson-usb package is not installed; "
    "using SNMP.":
        "USB nicht nutzbar: Paket epson-usb fehlt; es wird das Netzwerk "
        "(SNMP) benutzt.",
    "Missing IP address or printer host name.":
        "IP-Adresse oder Hostname des Druckers fehlt.",
}

# ---------------------------------------------------------------------------
# Texte mit Platzhaltern: (englische Vorlage, deutsche Vorlage). In der
# englischen Vorlage steht {} für einen beliebigen Teil, in der deutschen
# {0}, {1}, ... für den 1., 2., ... Teil.
# ---------------------------------------------------------------------------
TEMPLATES = [
    ('"{}" file save operation completed.', '"{0}" wurde gespeichert.'),
    ("Loaded file {}.", "Datei {0} geladen."),
    ("Cannot load file {}", "Datei {0} kann nicht geladen werden"),
    ("Empty PICKLE FILE {}.", "Leere PICKLE-Datei {0}."),
    ("Cannot load PICKLE file {}. {}", "PICKLE-Datei {0} nicht ladbar. {1}"),
    ("Printer {} is the only one in the list.",
     "Drucker {0} ist der einzige in der Liste."),
    ("Configuation of printer {} removed.",
     "Konfiguration von Drucker {0} entfernt."),
    ("Version: {}\n{}", "Version: {0}\n{1}"),
    ("Cannot open the browser: {}. The address is {}.",
     "Browser kann nicht geöffnet werden: {0}. Die Adresse ist {1}."),
    ("Cannot import epson_usb: {}", "epson_usb kann nicht geladen werden: {0}"),
    ("Cannot list USB devices: {}",
     "USB-Geräte können nicht aufgelistet werden: {0}"),
    ("{} USB device(s) found, but none could be opened (check that the "
     "printer is on and not held by another program).",
     "{0} USB-Gerät(e) gefunden, aber keins ließ sich öffnen (ist der "
     "Drucker an und von keinem anderen Programm belegt?)."),
    ("{} USB port(s) available in the list{}",
     "{0} USB-Anschluss/Anschlüsse in der Liste{1}"),
    ("Cannot enable the USB transport ({}); using SNMP.",
     "USB nicht nutzbar ({0}); es wird das Netzwerk (SNMP) benutzt."),
    ("Power off timer: {} minutes.", "Abschalt-Timer: {0} Minuten."),
    ("Printer serial number: {}.", "Seriennummer: {0}."),
    ("Printer WiFi MAC address: {}.", "WLAN-MAC-Adresse: {0}."),
    ("Current EEPROM values for {}: {}.", "Aktuelle EEPROM-Werte für {0}: {1}."),
    ('Cannot read EEPROM values for "{}" invalid printer model selected: {}. '
     "Possibly a printer firmware update disabled the operation.",
     'EEPROM-Werte für "{0}" nicht lesbar, falsches Druckermodell: {1}. '
     "Möglicherweise hat ein Firmware-Update den Vorgang gesperrt."),
    ("New EEPROM values: {}.", "Neue EEPROM-Werte: {0}."),
    ("{} of {} cells already held the requested value.",
     "{0} von {1} Zellen hatten den Wert schon."),
    ("Nothing to write: {} already had the requested value ({}); no cell was "
     "changed.",
     "Nichts zu schreiben: {0} hatte den Wert schon ({1}); keine Zelle "
     "geändert."),
    ("Set Power off timer: {} minutes. Restarting the printer is required for "
     "this change to take effect.",
     "Abschalt-Timer auf {0} Minuten gesetzt. Der Drucker muss neu gestartet "
     "werden."),
    ("Set WiFi MAC Address: {}.", "WLAN-MAC-Adresse gesetzt: {0}."),
    ("Set Printer Serial Number: {}.", "Seriennummer gesetzt: {0}."),
    ("First TI received time (YYYY-MM-DD): {}.",
     "Datum der Erstinbetriebnahme (JJJJ-MM-TT): {0}."),
    ("Set 'First TI received time' (YYYY-MM-DD) to: {}.",
     "Datum der Erstinbetriebnahme (JJJJ-MM-TT) gesetzt auf: {0}."),
    ('Unknown printer model "{}"', 'Unbekanntes Druckermodell "{0}"'),
    ("EEPROM values: {}.", "EEPROM-Werte: {0}."),
    ('Cannot read EEPROM values for addresses "{}" invalid printer model '
     "selected. Possibly a printer firmware update disabled the operation.",
     'EEPROM-Werte für Adressen "{0}" nicht lesbar, falsches Druckermodell. '
     "Möglicherweise hat ein Firmware-Update den Vorgang gesperrt."),
    ("{}/{} keys tried, now {}", "{0}/{1} Schlüssel probiert, jetzt {2}"),
    ("Detected read_key: {}.", "Gefundener Lese-Schlüssel (read_key): {0}."),
    ("You selected a model with the wrong read_key {} instead of {}. Using the "
     "detected one to go on.",
     "Das gewählte Modell hat den falschen Lese-Schlüssel {0} statt {1}. "
     "Es wird mit dem gefundenen weitergemacht."),
    ('Detected serial number "{}" at address {}.',
     'Seriennummer "{0}" an Adresse {1} gefunden.'),
    ('- found pattern "{}" at address {}',
     '- Muster "{0}" an Adresse {1} gefunden'),
    ("Current EEPROM value for the last byte of the serial number: {}: {}.",
     "Aktueller EEPROM-Wert des letzten Bytes der Seriennummer: {0}: {1}."),
    ("The serial number addresses {} of the selected printer is different from "
     "the detected one {}, which will be used to go on.",
     "Die Seriennummer-Adressen {0} des gewählten Druckers weichen von den "
     "gefundenen {1} ab; es wird mit den gefundenen weitergemacht."),
    ("Detected write_key: {}", "Gefundener Schreib-Schlüssel (write_key): {0}"),
    ("The key was verified by writing address {}, reading the new value back "
     "and restoring {}.",
     "Der Schlüssel wurde geprüft: Adresse {0} geschrieben, zurückgelesen "
     "und {1} wiederhergestellt."),
    ("The selected write key {} is different from the detected one, which will "
     "be used to go on.",
     "Der gewählte Schreib-Schlüssel {0} weicht vom gefundenen ab; es wird "
     "mit dem gefundenen weitergemacht."),
    ("Models with same read_key: {}", "Modelle mit gleichem Lese-Schlüssel: {0}"),
    ("Models with same write_key: {}",
     "Modelle mit gleichem Schreib-Schlüssel: {0}"),
    ("Models with same access keys: {}",
     "Modelle mit gleichen Zugangsschlüsseln: {0}"),
    ("Found data: {}.", "Gefundene Daten: {0}."),
    ("Clean nozzless failure: {}", "Düsenreinigung fehlgeschlagen: {0}"),
    ("Going to write EEPROM: {}.", "EEPROM wird geschrieben: {0}."),
    ("Write EEPROM failed at address {} (value {}); the following addresses "
     "were not written. The console log reports the printer's answer.",
     "EEPROM schreiben fehlgeschlagen an Adresse {0} (Wert {1}); die "
     "folgenden Adressen wurden nicht geschrieben. Das Konsolenprotokoll "
     "zeigt die Antwort des Druckers."),
    ("Found printer '{}' at {} (hostname: {})",
     "Drucker '{0}' gefunden unter {1} (Hostname: {2})"),
    ("Found {} printers:", "{0} Drucker gefunden:"),
    ("{} found at {} (hostname: {})", "{0} gefunden unter {1} (Hostname: {2})"),
    ("Cannot contact printer {} (hostname: {}).",
     "Drucker {0} nicht erreichbar (Hostname: {1})."),
    ("Detected {} device(s):", "{0} Gerät(e) gefunden:"),
    ("'USB Port' lists the {} port(s) that can be opened out of these {}: "
     "choose one to pin it instead of letting the library pick the first it "
     "can open.",
     "'USB-Anschluss' zeigt die {0} öffenbaren von diesen {1} Anschlüssen: "
     "einen auswählen, um ihn fest zu verwenden."),
    ("Welcome to the {}", "Willkommen in der {0}"),
    ("Select a {} printer configuration file, or enter a Web URL",
     "{0}-Druckerkonfiguration auswählen oder Web-Adresse eingeben"),
    ("Epson Printer Configuration - v{}", "Epson Printer Configuration - v{0}"),
]


def _compile(templates):
    out = []
    for en, de in templates:
        pattern = "^" + re.escape(en).replace(r"\{\}", "(.+?)") + "$"
        out.append((re.compile(pattern, re.S), de))
    return out


_PATTERNS = _compile(TEMPLATES)
_MISSING_FILE = os.environ.get("TANKWART_DE_FEHLEND")
_missing_seen = set()


def _note_missing(core):
    if not _MISSING_FILE or core in _missing_seen:
        return
    if not any(c.isalpha() for c in core):
        return
    _missing_seen.add(core)
    try:
        with open(_MISSING_FILE, "a", encoding="utf-8") as fh:
            fh.write(repr(core) + "\n")
    except OSError:
        pass


def tr(text):
    """Deutsche Fassung von ``text``; unbekannte Texte bleiben unverändert."""
    if not isinstance(text, str) or not text.strip():
        return text
    core = text.strip()
    lead = text[: len(text) - len(text.lstrip())]
    trail = text[len(text.rstrip()):]
    de = DE.get(core)
    if de is None:
        for pattern, template in _PATTERNS:
            m = pattern.match(core)
            if m:
                de = template.format(*m.groups())
                break
    if de is None:
        _note_missing(core)
        return text
    return lead + de + trail


_SENTENCE_SPLIT = re.compile(r"(?<=[.!?])\s+")


def tr_sentences(text):
    """Wie tr(), übersetzt aber notfalls Satz für Satz.

    Für Hinweistexte, die ui.py aus mehreren Teilen zusammensetzt
    (Beschreibung + Warnung).
    """
    if not isinstance(text, str) or not text.strip():
        return text
    whole = tr(text)
    if whole != text:
        return whole
    parts = _SENTENCE_SPLIT.split(text.strip())
    if len(parts) < 2:
        return text
    return " ".join(tr(p) for p in parts)


_TEXT_KEYS = ("text", "label", "title", "message", "detail")
_installed = False


def install():
    """Übersetzung in tkinter einhängen (einmalig, vor dem Fensteraufbau)."""
    global _installed
    if _installed:
        return
    _installed = True

    # 1. Alle Widget-Optionen (Erzeugen, configure, Menüeinträge, Dialoge)
    original_options = tkinter.Misc._options

    def _options(self, cnf, kw=None):
        def fix(d):
            if not d or not isinstance(d, dict):
                return d
            if not any(k in d for k in _TEXT_KEYS):
                return d
            d = dict(d)
            for k in _TEXT_KEYS:
                if k in d and isinstance(d[k], str):
                    d[k] = tr(d[k])
            return d
        return original_options(self, fix(cnf), fix(kw))

    tkinter.Misc._options = _options

    # 2. Fenstertitel
    original_title = tkinter.Wm.wm_title

    def wm_title(self, string=None):
        return original_title(self, tr(string) if string else string)

    tkinter.Wm.wm_title = wm_title
    tkinter.Wm.title = wm_title

    # 3. Meldungsfenster (showinfo, showerror, askyesno, ...)
    original_show = messagebox._show

    def _show(title=None, message=None, *args, **kwargs):
        return original_show(tr(title), tr(message), *args, **kwargs)

    messagebox._show = _show

    # 4. Spaltenköpfe und Einträge der Baumansicht (nur bekannte Texte)
    original_heading = ttk.Treeview.heading

    def heading(self, column, option=None, **kw):
        if "text" in kw:
            kw["text"] = tr(kw["text"])
        return original_heading(self, column, option, **kw)

    ttk.Treeview.heading = heading

    original_insert = ttk.Treeview.insert

    def tree_insert(self, parent, index, iid=None, **kw):
        if isinstance(kw.get("text"), str) and kw["text"].strip() in DE:
            kw["text"] = tr(kw["text"])
        return original_insert(self, parent, index, iid, **kw)

    ttk.Treeview.insert = tree_insert

    # 5. Menüeinträge werden in ui.py auch über ihren (englischen) Namen
    #    angesprochen, z. B. entryconfig("Clear printer list", state=...).
    #    Nach der Übersetzung heißt der Eintrag anders: den Namen mit
    #    übersetzen, sonst meldet Tk "bad menu entry index".
    def _menu_index_wrapper(original):
        def wrapper(self, index, *args, **kwargs):
            if isinstance(index, str):
                index = tr(index)
            return original(self, index, *args, **kwargs)
        return wrapper

    for name in ("entryconfigure", "entrycget", "index", "invoke", "delete",
                 "type", "yposition"):
        setattr(tkinter.Menu, name,
                _menu_index_wrapper(getattr(tkinter.Menu, name)))
    tkinter.Menu.entryconfig = tkinter.Menu.entryconfigure


def wrap_text_widget(widget):
    """Text, der in ``widget`` (z. B. das Statusfeld) geschrieben wird, übersetzen."""
    original = widget.insert

    def insert(index, chars, *args):
        return original(index, tr(chars), *args)

    widget.insert = insert
    return widget
