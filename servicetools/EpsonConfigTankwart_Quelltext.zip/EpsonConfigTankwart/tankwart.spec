# -*- mode: python ; coding: utf-8 -*-
#
# Drucker-Tankwart-Ausgabe von epson_print_conf als einzelne .exe bauen.
# Abgeleitet von Ircamas epson_print_conf.spec ("--default"-Variante, ohne
# pickle-Datei), dazu Tankwart-Logo, Icon, Startbild und Zusatzmodelle.
#
# Bauen (im Ordner epson_print_conf, mit installierter requirements.txt
# und pyinstaller):
#     python -m PyInstaller --noconfirm tankwart.spec
# Ergebnis: dist\DruckerTankwart_EpsonConfig.exe

import os
from PIL import Image
from PyInstaller.utils.hooks import collect_submodules, collect_data_files

BASENAME = "DruckerTankwart_EpsonConfig"
PROGRAM = ["tankwart_gui.py"]
ICON_FILE = "build_icon.ico"
SPLASH_IMAGE = "build_splash.png"

# Fenstersymbol der exe aus dem Tankwart-Icon
Image.open(os.path.join("assets", "icon_256.png")).save(
    ICON_FILE, sizes=[(16, 16), (32, 32), (48, 48), (256, 256)]
)

# Startbild: weisse Flaeche mit Tankwart-Logo und Beeren-Linie
logo = Image.open(os.path.join("assets", "header_logo.png")).convert("RGBA")
splash = Image.new("RGB", (420, 160), "white")
splash.paste(logo, ((420 - logo.width) // 2, 28), logo)
splash.paste(Image.new("RGB", (420, 6), "#951B54"), (0, 154))
splash.save(SPLASH_IMAGE)

with open(PROGRAM[0], "w") as fh:
    fh.write(
        "import pyi_splash\n"
        "import ui\n"
        "app = ui.main()\n"
        "pyi_splash.close()\n"
        "app.mainloop()\n"
    )

# black: https://github.com/pyinstaller/pyinstaller/issues/8270
black_submodules = collect_submodules("black")
blib2to3_submodules = collect_submodules("blib2to3")
blib2to3_data = collect_data_files("blib2to3")

# mypyc-kompilierte Pakete (tomli, black, pytokens ...) brauchen ein
# Hilfsmodul "<hash>__mypyc", das PyInstaller nicht selbst findet. Der Name
# aendert sich mit jeder Paketversion, daher hier alle installierten suchen
# statt feste Namen einzutragen (sonst: "No module named '...__mypyc'").
import glob
import sysconfig
mypyc_modules = sorted({
    os.path.basename(path).split(".")[0]
    for folder in {sysconfig.get_paths()["purelib"],
                   sysconfig.get_paths()["platlib"]}
    for path in glob.glob(os.path.join(folder, "*__mypyc*.pyd"))
    + glob.glob(os.path.join(folder, "*__mypyc*.so"))
})
print("mypyc-Module:", mypyc_modules)

epson_usb_submodules = [
    name for name in collect_submodules("epson_usb")
    if not name.startswith("epson_usb.tests")
] + ["epson_usb_bridge"]

a = Analysis(
    PROGRAM,
    pathex=["."],
    binaries=[],
    datas=[("assets", "assets")] + blib2to3_data,
    hiddenimports=[
        "tankwart_theme", "tankwart_de", "zusatz_drucker", "drucker_db_generiert", "tankwart_auto",
        "tk_date_entry",
        "click", "json", "platform",
        "mypy_extensions", "pathspec", "_black_version", "platformdirs",
    ] + mypyc_modules + collect_submodules("tomli")
      + collect_submodules("pytokens")
      + epson_usb_submodules + black_submodules + blib2to3_submodules,
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
    optimize=0,
)

pyz = PYZ(a.pure)
splash = Splash(
    SPLASH_IMAGE,
    binaries=a.binaries,
    datas=a.datas,
    text_pos=None,
    minify_script=True,
    always_on_top=True,
)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    splash,
    splash.binaries,
    [],
    name=BASENAME,
    icon=ICON_FILE,
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,  # kein schwarzes Konsolenfenster
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

for f in (SPLASH_IMAGE, PROGRAM[0], ICON_FILE):
    try:
        os.remove(f)
    except OSError:
        pass
