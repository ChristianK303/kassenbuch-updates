"""
Drucker-Tankwart-Optik fuer die Oberflaeche von epson_print_conf (ui.py).

Farben, Schriften, Logo und Fenstersymbole wie im EpsonServiceTool
(epson_tool.py). Alles Optische steht hier, damit ui.py von Ircama nur an
wenigen Stellen geaendert werden muss und Updates leicht einzuspielen sind.

Verwendung in ui.py::

    tankwart_theme.apply(self)            # direkt nach tk.Tk.__init__
    tankwart_theme.build_header(self, VERSION).grid(row=0, column=0, ...)
"""
from pathlib import Path
import tkinter as tk
from tkinter import ttk
import tkinter.font as tkfont

BRAND_NAME = "Drucker Tankwart"
APP_TITLE = "Epson-Druckerkonfiguration"
ASSET_DIR = Path(__file__).resolve().parent / "assets"
FONT = "Segoe UI"

# Farben aus dem Drucker-Tankwart-Logo (wie epson_tool.py)
COLORS = {
    "brand": "#951B54",        # Logofarbe (Beere)
    "brand_dark": "#6E1440",   # gedrueckt / Statusleiste
    "brand_hover": "#A8336B",
    "brand_light": "#F6E8EF",  # Flaechen, Balkenhintergrund
    "bg": "#FBF8F9",           # Fensterhintergrund
    "surface": "#FFFFFF",
    "border": "#E4D3DB",
    "text": "#2E1A24",
    "muted": "#7A6570",
}

#: Farben fuer Statustext und Baumansicht (ersetzt ThemeColors in ui.py).
#: Immer hell, weil das Fenster immer im hellen Tankwart-Stil gezeichnet wird.
PALETTE = {
    "treeview_heading_bg": COLORS["brand"],
    "treeview_heading_fg": "white",
    "tree_key": COLORS["text"],
    "tree_key_value": COLORS["brand"],
    "tree_value": "#1F5F8B",
    "status_error": "#C0262D",
    "status_warn": "#B35C00",
    "status_note": COLORS["brand"],
    "status_info": "#2E7D32",
}


def load_image(name):
    """PNG aus assets laden; None, wenn es fehlt oder nicht lesbar ist."""
    path = ASSET_DIR / name
    if not path.exists():
        return None
    try:
        return tk.PhotoImage(file=str(path))
    except tk.TclError:
        return None


def apply(root):
    """Farbschema, Schriften und Fenstersymbol auf ``root`` anwenden."""
    c = COLORS
    root.configure(background=c["bg"])
    for name in ("TkDefaultFont", "TkTextFont", "TkMenuFont",
                 "TkHeadingFont", "TkCaptionFont"):
        try:
            tkfont.nametofont(name).configure(family=FONT, size=10)
        except tk.TclError:
            pass

    # klassische Tk-Widgets (Text, Frame, Listbox der Combobox)
    root.option_add("*TCombobox*Listbox.background", c["surface"])
    root.option_add("*TCombobox*Listbox.foreground", c["text"])
    root.option_add("*TCombobox*Listbox.selectBackground", c["brand"])
    root.option_add("*TCombobox*Listbox.selectForeground", "white")
    root.option_add("*Text.background", c["surface"])
    root.option_add("*Text.foreground", c["text"])
    root.option_add("*Text.selectBackground", c["brand"])
    root.option_add("*Text.selectForeground", "white")
    root.option_add("*Text.highlightColor", c["brand"])
    root.option_add("*Text.highlightBackground", c["border"])
    root.option_add("*Text.relief", "flat")
    root.option_add("*Frame.background", c["bg"])
    root.option_add("*Toplevel.background", c["bg"])
    root.option_add("*Listbox.selectBackground", c["brand"])
    root.option_add("*Listbox.selectForeground", "white")

    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure(".", background=c["bg"], foreground=c["text"],
                    font=(FONT, 10), bordercolor=c["border"],
                    focuscolor=c["brand"], lightcolor=c["bg"],
                    darkcolor=c["bg"], troughcolor=c["brand_light"],
                    selectbackground=c["brand"], selectforeground="white")
    style.configure("TFrame", background=c["bg"])
    style.configure("Header.TFrame", background=c["surface"])
    style.configure("Brandline.TFrame", background=c["brand"])
    style.configure("TLabel", background=c["bg"], foreground=c["text"])
    style.configure("Card.TLabel", background=c["surface"])
    style.configure("HeaderTitle.TLabel", background=c["surface"],
                    foreground=c["brand"], font=(FONT, 16, "bold"))
    style.configure("HeaderSub.TLabel", background=c["surface"],
                    foreground=c["muted"], font=(FONT, 9))

    # Rahmen mit Ueberschrift (Power-off Timer, Status, ...)
    style.configure("TLabelframe", background=c["bg"],
                    bordercolor=c["border"], lightcolor=c["bg"],
                    darkcolor=c["bg"], relief="solid", borderwidth=1)
    style.configure("TLabelframe.Label", background=c["bg"],
                    foreground=c["brand"], font=(FONT, 10, "bold"))

    # Buttons: weiss mit Beeren-Schrift, Hauptaktion Beere gefuellt
    style.configure("TButton", background=c["surface"],
                    foreground=c["brand"], bordercolor=c["brand"],
                    lightcolor=c["surface"], darkcolor=c["surface"],
                    font=(FONT, 10, "bold"), padding=(10, 5),
                    focusthickness=1, justify="center", anchor="center")
    style.map("TButton",
              background=[("disabled", c["bg"]), ("pressed", c["brand_light"]),
                          ("active", c["brand_light"])],
              foreground=[("disabled", c["muted"])],
              bordercolor=[("disabled", c["border"])])
    style.configure("Accent.TButton", background=c["brand"],
                    foreground="white", bordercolor=c["brand"],
                    lightcolor=c["brand"], darkcolor=c["brand"])
    style.map("Accent.TButton",
              background=[("disabled", c["border"]),
                          ("pressed", c["brand_dark"]),
                          ("active", c["brand_hover"])],
              lightcolor=[("pressed", c["brand_dark"]),
                          ("active", c["brand_hover"])],
              darkcolor=[("pressed", c["brand_dark"]),
                         ("active", c["brand_hover"])],
              foreground=[("disabled", "white")])

    # Eingabefelder
    for widget in ("TEntry", "TCombobox", "TSpinbox"):
        style.configure(widget, fieldbackground=c["surface"],
                        background=c["surface"], foreground=c["text"],
                        arrowcolor=c["brand"], bordercolor=c["border"],
                        lightcolor=c["surface"], darkcolor=c["surface"],
                        insertcolor=c["text"], padding=3)
        style.map(widget,
                  bordercolor=[("focus", c["brand"])],
                  fieldbackground=[("readonly", c["surface"]),
                                   ("disabled", c["bg"])],
                  foreground=[("disabled", c["muted"])],
                  selectbackground=[("focus", c["brand"])],
                  selectforeground=[("focus", "white")])

    for widget in ("TRadiobutton", "TCheckbutton"):
        style.configure(widget, background=c["bg"], foreground=c["text"],
                        indicatorbackground=c["surface"],
                        indicatorforeground=c["brand"])
        style.map(widget,
                  background=[("active", c["bg"])],
                  indicatorbackground=[("selected", c["brand"]),
                                       ("pressed", c["brand_light"])],
                  indicatorforeground=[("selected", "white")])

    # Baumansicht im Statusbereich
    style.configure("Treeview", background=c["surface"],
                    fieldbackground=c["surface"], foreground=c["text"],
                    bordercolor=c["border"], rowheight=22)
    style.map("Treeview",
              background=[("selected", c["brand"])],
              foreground=[("selected", "white")])
    style.configure("Treeview.Heading", background=c["brand"],
                    foreground="white", relief="flat",
                    font=(FONT, 9, "bold"))
    style.map("Treeview.Heading", background=[("active", c["brand_hover"])])

    style.configure("Horizontal.TProgressbar", background=c["brand"],
                    troughcolor=c["brand_light"], bordercolor=c["border"],
                    lightcolor=c["brand"], darkcolor=c["brand"])
    for orient in ("Vertical", "Horizontal"):
        style.configure(orient + ".TScrollbar", background=c["brand_light"],
                        troughcolor=c["bg"], bordercolor=c["bg"],
                        arrowcolor=c["brand"], lightcolor=c["brand_light"],
                        darkcolor=c["brand_light"])
    style.configure("TNotebook", background=c["bg"], bordercolor=c["border"])
    style.configure("TNotebook.Tab", background=c["brand_light"],
                    foreground=c["brand"], padding=(10, 4))
    style.map("TNotebook.Tab",
              background=[("selected", c["surface"])])

    # Fenstersymbol (gilt auch fuer alle Unterfenster)
    icons = [img for img in (load_image("icon_%d.png" % s)
                             for s in (256, 48, 32, 16)) if img]
    if icons:
        root.iconphoto(True, *icons)
        root._tankwart_icons = icons  # Referenz halten


def window_title(version):
    return "%s - %s - v%s" % (BRAND_NAME, APP_TITLE, version)


def build_header(root, version):
    """Kopfzeile mit Logo und Titel; der Aufrufer platziert sie (grid)."""
    outer = ttk.Frame(root, style="TFrame")
    outer.columnconfigure(0, weight=1)
    header = ttk.Frame(outer, style="Header.TFrame", padding=(14, 4))
    header.grid(row=0, column=0, sticky="ew")
    logo = load_image("header_logo.png")
    if logo is not None:
        # Originalgroesse (247 x 84): Tk skaliert nur ganzzahlig und pixelig
        label = ttk.Label(header, image=logo, style="Card.TLabel")
        label.image = logo
        label.pack(side="left")
    else:
        ttk.Label(header, text=BRAND_NAME.upper(),
                  style="HeaderTitle.TLabel").pack(side="left")
    titles = ttk.Frame(header, style="Header.TFrame")
    titles.pack(side="right")
    ttk.Label(titles, text=APP_TITLE, style="HeaderTitle.TLabel").pack(
        anchor="e")
    ttk.Label(titles, text="Version %s  ·  %s" % (version, BRAND_NAME),
              style="HeaderSub.TLabel").pack(anchor="e")
    ttk.Frame(outer, style="Brandline.TFrame", height=3).grid(
        row=1, column=0, sticky="ew")
    return outer
