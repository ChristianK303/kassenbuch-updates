"""
Zusaetzliche Druckermodelle, die in epson_print_conf (Ircama) fehlen.

Die Eintraege haben dasselbe Format wie ``EpsonPrinter.PRINTER_CONFIG`` und
werden beim Start mit ``register(EpsonPrinter)`` hinzugefuegt. Modelle, die
die Bibliothek selbst schon kennt, werden nie ueberschrieben.

Nur belegte Werte eintragen: ein falscher Schluessel oder falsche Adressen
koennen beim Zuruecksetzen den Drucker unbrauchbar machen.

Quellen
-------
ET-2850 / L4260-Familie:
  * Schluessel und Zaehleradressen: reinkpy, epson.toml
    (https://codeberg.org/atufi/reinkpy), Gruppe "ET-2850, ET-2851, ET-2853,
    ET-2855, L4260 ... L4269": rkey 0x364A -> read_key [74, 54],
    wkey1 "Arantifo"; Reset 0x1C,0x34,0x35,0x36,0x37,0xFF =
    0,0,0,0x5E,0x5E,0x5E; Zaehler 0x2F, 0x30/31, 0x32/33, 0xFC/FD, 0xFE.
    Dieselbe Speicheraufteilung wie das ET-2800 in epson_print_conf.
  * Erfolgreicher Reset eines ET-2850 mit diesen Daten gemeldet in
    https://github.com/Ircama/epson_print_conf/issues/26 (dort auch der
    Hinweis, dass neuere Firmware den Zugriff per Netzwerk sperrt -> USB).
  * Prozent-Teiler (nur fuer die Anzeige in %) aus dem in Issue #26
    geposteten Eintrag; am echten Geraet nicht nachgemessen.
"""
import copy

EXTRA_PRINTER_CONFIG = {
    "ET-2850": {
        "alias": [
            "ET-2851", "ET-2853", "ET-2855", "ET-2856",
            "L4260", "L4261", "L4263", "L4265", "L4266", "L4267",
            "L4268", "L4269",
        ],
        "read_key": [74, 54],
        "write_key": b"Arantifo",
        "main_waste": {"oids": [48, 49, 47], "divider": 109.13},
        "borderless_waste": {"oids": [50, 51, 47], "divider": 16.31},
        "third_waste": {"oids": [252, 253, 254], "divider": 15.3},
        "raw_waste_reset": {
            48: 0, 49: 0, 47: 0, 52: 0, 53: 0, 54: 94, 50: 0, 51: 0,
            55: 94, 28: 0, 252: 0, 253: 0, 254: 0, 255: 94,
        },
        "stats": {
            "Maintenance required level of 1st waste ink counter": [54],
            "Maintenance required level of 2nd waste ink counter": [55],
            "Maintenance required level of 3rd waste ink counter": [255],
            "Total print pass counter": [133, 132, 131, 130],
            "Total print page counter - rear": [755, 754, 753, 752],
            "Total print page counter - duplex": [763, 762, 761, 760],
            "Total scan counter": [1843, 1842, 1841, 1840],
            "Ink replacement counter %-- Black": [554],
            "Ink replacement counter %-- Cyan": [555],
            "Ink replacement counter %-- Magenta": [556],
            "Ink replacement counter %-- Yellow": [557],
        },
        "serial_number": range(1604, 1614),
    },
}


def register(printer_cls):
    """Fuegt die Zusatzmodelle in ``printer_cls.PRINTER_CONFIG`` ein.

    Muss vor dem ersten ``printer_cls()`` laufen; die Bibliothek loest
    ``alias`` beim Erzeugen eines Objekts selbst auf.
    """
    config = printer_cls.PRINTER_CONFIG
    added = []
    for name, entry in EXTRA_PRINTER_CONFIG.items():
        names = [name] + list(entry.get("alias", []))
        if any(n in config for n in names):
            continue  # Bibliothek kennt das Modell schon: ihre Daten gelten
        config[name] = copy.deepcopy(entry)
        added.append(name)
    return added
