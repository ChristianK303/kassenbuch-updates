"""
Zusaetzliche Druckermodelle, die in epson_print_conf (Ircama) fehlen.

Die Eintraege haben dasselbe Format wie ``EpsonPrinter.PRINTER_CONFIG`` und
werden beim Start mit ``register(EpsonPrinter)`` hinzugefuegt. Modelle, die
die Bibliothek selbst schon kennt, werden nie ueberschrieben.

Nur belegte Werte eintragen: ein falscher Schluessel oder falsche Adressen
koennen beim Zuruecksetzen den Drucker unbrauchbar machen.

Quellen
-------
ET-2850 / L4260-Familie:
  * Schluessel und Zaehleradressen: reinkpy, epson.toml
    (https://codeberg.org/atufi/reinkpy), Gruppe "ET-2850, ET-2851, ET-2853,
    ET-2855, L4260 ... L4269": rkey 0x364A -> read_key [74, 54],
    wkey1 "Arantifo"; Reset 0x1C,0x34,0x35,0x36,0x37,0xFF =
    0,0,0,0x5E,0x5E,0x5E; Zaehler 0x2F, 0x30/31, 0x32/33, 0xFC/FD, 0xFE.
    Dieselbe Speicheraufteilung wie das ET-2800 in epson_print_conf.
  * Erfolgreicher Reset eines ET-2850 mit diesen Daten gemeldet in
    https://github.com/Ircama/epson_print_conf/issues/26 (dort auch der
    Hinweis, dass neuere Firmware den Zugriff per Netzwerk sperrt -> USB).
  * Prozent-Teiler (nur fuer die Anzeige in %) aus dem in Issue #26
    geposteten Eintrag; am echten Geraet nicht nachgemessen.

ET-2870 / ET-2871 / ET-2873 / ET-2875:
  * Eintrag unveraendert erzeugt mit Ircamas parse_devices.py aus der
    Epson-Geraetedatenbank devices.xml
    (https://github.com/user-attachments/files/23294840/devices.xml, dort
    "Epson ET-2870/2871/2873/2875", Technik wie L3260), auf die Ircama in
    https://github.com/Ircama/epson_print_conf/issues/127 verweist.
  * Deckt sich mit reinkpy (Gruppe mit ET-2800/ET-2810/L3250: rkey 0x364A,
    wkey1 "Maribaya", gleiche Reset-Zellen). waste_reset_commit {0x100: 0xFE}
    wie beim ET-2812 in epson_print_conf (dort an einem ET-2814 nachgewiesen).
  * Neuere Firmware dieser Generation sperrt den Zugriff per Netzwerk
    (vgl. ET-2862 in Ircamas README) -> per USB arbeiten.
"""
import copy

EXTRA_PRINTER_CONFIG = {
    "ET-2850": {
        "alias": [
            "ET-2851", "ET-2853", "ET-2855", "ET-2856",
            "L4260", "L4261", "L4263", "L4265", "L4266", "L4267",
            "L4268", "L4269",
        ],
        "read_key": [74, 54],
        "write_key": b"Arantifo",
        "main_waste": {"oids": [48, 49, 47], "divider": 109.13},
        "borderless_waste": {"oids": [50, 51, 47], "divider": 16.31},
        "third_waste": {"oids": [252, 253, 254], "divider": 15.3},
        "raw_waste_reset": {
            48: 0, 49: 0, 47: 0, 52: 0, 53: 0, 54: 94, 50: 0, 51: 0,
            55: 94, 28: 0, 252: 0, 253: 0, 254: 0, 255: 94,
        },
        "stats": {
            "Maintenance required level of 1st waste ink counter": [54],
            "Maintenance required level of 2nd waste ink counter": [55],
            "Maintenance required level of 3rd waste ink counter": [255],
            "Total print pass counter": [133, 132, 131, 130],
            "Total print page counter - rear": [755, 754, 753, 752],
            "Total print page counter - duplex": [763, 762, 761, 760],
            "Total scan counter": [1843, 1842, 1841, 1840],
            "Ink replacement counter %-- Black": [554],
            "Ink replacement counter %-- Cyan": [555],
            "Ink replacement counter %-- Magenta": [556],
            "Ink replacement counter %-- Yellow": [557],
        },
        "serial_number": range(1604, 1614),
    },
    "ET-2870": {
        "alias": ["ET-2871", "ET-2873", "ET-2875"],
        "read_key": [74, 54],
        "write_key": b"Maribaya",
        "main_waste": {"oids": [48, 49, 47], "divider": 63.46},
        "borderless_waste": {"oids": [50, 51, 47], "divider": 34.16},
        "third_waste": {"oids": [252, 253, 254], "divider": 13.0},
        "raw_waste_reset": {
            48: 0, 49: 0, 47: 0, 52: 0, 53: 0, 54: 94, 50: 0, 51: 0,
            55: 94, 28: 0, 252: 0, 253: 0, 254: 0, 255: 94,
        },
        "waste_reset_commit": {0x100: 0xFE},
        "stats": {
            "Total print pass counter": [133, 132, 131, 130],
            "Total print page counter": [776, 775, 774, 773],
            "Total scan counter": [1843, 1842, 1841, 1840],
            "Maintenance required level of 1st waste ink counter": [54],
            "Maintenance required level of 2nd waste ink counter": [55],
            "Maintenance required level of 3rd waste ink counter": [255],
        },
        "serial_number": range(1604, 1614),
    },
}


def finde_modell(name, valid_printers):
    """Datenbank-Modell zu dem Namen, den der Drucker meldet, oder None.

    Der Drucker meldet z. B. "EPSON ET-2850 Series" (Netzwerk) oder
    "ET-2850 Series" (USB, Kennung MDL/DES). Probiert werden der Name selbst,
    die Varianten aus epson_print_conf.get_printer_models() und der Name ohne
    "EPSON"/"Series".
    """
    if not name:
        return None
    if isinstance(name, (list, tuple)):
        name = name[0] if name else ""
    name = str(name).strip()
    if not name:
        return None
    candidates = [name]
    try:
        from epson_print_conf import get_printer_models
        candidates += list(get_printer_models(name))
    except Exception:
        pass
    bare = " ".join(w for w in name.replace("/", " ").split()
                    if w.upper() not in ("EPSON", "SERIES"))
    candidates += [bare] + bare.split()
    valid = set(valid_printers)
    for c in candidates:
        if c in valid:
            return c
    # Gross-/Kleinschreibung ignorieren (z. B. "Et-2850")
    upper = {v.upper(): v for v in valid}
    for c in candidates:
        if c.upper() in upper:
            return upper[c.upper()]
    return None


def register(printer_cls):
    """Fuegt die Zusatzmodelle in ``printer_cls.PRINTER_CONFIG`` ein.

    Muss vor dem ersten ``printer_cls()`` laufen; die Bibliothek loest
    ``alias`` beim Erzeugen eines Objekts selbst auf.
    """
    config = printer_cls.PRINTER_CONFIG

    def known():
        # Namen UND Aliasnamen: vor dem ersten printer_cls() stehen Aliasse
        # noch im Eintrag und nicht als eigener Schluessel.
        names = set(config)
        for entry in config.values():
            if isinstance(entry, dict):
                names.update(entry.get("alias", []) or [])
        return names

    added = []
    names_known = known()
    for name, entry in EXTRA_PRINTER_CONFIG.items():
        names = [name] + list(entry.get("alias", []))
        if any(n in names_known for n in names):
            continue  # Bibliothek kennt das Modell schon: ihre Daten gelten
        config[name] = copy.deepcopy(entry)
        names_known.update(names)
        added.append(name)

    # Automatisch erzeugte Modelle (drucker_db_generiert.py): je Modell
    # einzeln und nur, wenn es noch nirgends steht.
    try:
        from drucker_db_generiert import GRUPPEN
    except ImportError:
        GRUPPEN = {}
    for gruppe in GRUPPEN.values():
        for model in gruppe["modelle"]:
            if model in names_known:
                continue
            config[model] = copy.deepcopy(gruppe["config"])
            names_known.add(model)
            added.append(model)
    return added
